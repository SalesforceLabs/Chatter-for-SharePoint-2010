﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Runtime.Serialization;
using SalesForce.ChatterMiddleTier;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Linq;
using System.Net;

namespace SalesForce.ChatterWP2010
{
    public partial class LikesUserList : LayoutsPageBase
    {
        #region User defined objects
        string m_sUserID = string.Empty;
        const string CONST_QS_FEEDID = "FID";
        const string CONST_QS_USERID = "UID";
        const string CONST_QS_CONSUMER_KEY = "CK";
        const string CONST_QS_CONSUMER_SECRET = "CS";
        const string CONST_QS_WEBURL = "WebUrl";
        const string CONST_QS_CALL_BACK_URL = "CU";
        List<Like> oLikeList = new List<Like>();
        GlobalEntities m_oUserEntities = new GlobalEntities();
        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();
        #endregion

        #region Page_Load
        protected void Page_Load(object sender, EventArgs e)
        {
            LikePage oLikePage = new LikePage();
            string sFeedID = string.Empty;
            try
            {
                #region Get QueryString Params
                // Get QueryString param for Feed ID
                sFeedID = Request.QueryString[CONST_QS_FEEDID].ToString();

                // Get QueryString param for User Index
                if (!string.IsNullOrEmpty(Request.QueryString[CONST_QS_USERID]))
                    m_sUserID = Request.QueryString[CONST_QS_USERID].ToString();
                #endregion

                SetAPIInfoFrmVS();

                List<Like> oLikes = m_oChatterRESTAPI.GetFeedItemLikesUpdate(sFeedID);
                var varlikeID = oLikes.Where(l => l.User.ID != m_sUserID);
                oLikeList = varlikeID.ToList();

                if (!IsPostBack)
                {
                    // Bind the grid
                    gvUserList.DataSource = varlikeID.ToList();
                    gvUserList.DataBind();
                    EnableDisablePageLinks();
                }
            }
            catch (WebException webex)
            {
                divError.Visible = true;
                lblError.Text = webex.Message;
                m_oSFChatterBAL.HandleError(webex.Message);
            }
            catch (Exception ex)
            {
                divError.Visible = true;
                lblError.Text = ex.Message;
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }
        #endregion

        #region gvUserList_OnPageIndexChanging
        protected void gvUserList_OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            try
            {
                gvUserList.PageIndex = e.NewPageIndex;
                gvUserList.DataBind();
            }
            catch (Exception exp)
            {
                divError.Visible = true;
                lblError.Text = exp.Message;
                m_oSFChatterBAL.HandleError(exp.Message);
            }
        }
        #endregion

        #region EnableDisablePageLinks
        /// <summary>
        /// Enables/Disables the Previous and Next page links depending on the current page index
        /// </summary>
        private void EnableDisablePageLinks()
        {
            try
            {
                // If first page
                if (gvUserList.PageIndex == 0)
                {
                    // Disable the 'Previous' link
                    (gvUserList.BottomPagerRow.FindControl("lnkPrevious") as LinkButton).Enabled = false;
                    (gvUserList.BottomPagerRow.FindControl("lnkPrevious") as LinkButton).ForeColor = System.Drawing.Color.Gray;
                }

                // If last page
                if (gvUserList.PageIndex == gvUserList.PageCount - 1)
                {
                    // Disable the 'next' link
                    (gvUserList.BottomPagerRow.FindControl("lnkNext") as LinkButton).Enabled = false;
                    (gvUserList.BottomPagerRow.FindControl("lnkNext") as LinkButton).ForeColor = System.Drawing.Color.Gray;
                }
            }
            catch (Exception exp)
            {
                divError.Visible = true;
                lblError.Text = exp.Message;
                m_oSFChatterBAL.HandleError(exp.Message);
            }
        }
        #endregion

        #region PageChange_OnCommand
        /// <summary>
        /// Set the Page Index depending on the link (Previous/Next) clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PageChange_OnCommand(object sender, CommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "Previous":
                        gvUserList.PageIndex = gvUserList.PageIndex - 1;
                        break;

                    case "Next":
                        gvUserList.PageIndex = gvUserList.PageIndex + 1;
                        break;
                }
                gvUserList.DataSource = oLikeList;
                gvUserList.DataBind();
                EnableDisablePageLinks();
            }
            catch (Exception exp)
            {
                divError.Visible = true;
                lblError.Text = exp.Message;
                m_oSFChatterBAL.HandleError(exp.Message);
            }
        }

        protected void gvUserList_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                if (e.Row.RowType != DataControlRowType.DataRow)
                    return;
                string m_sOAuth_Token = "{0}?oauth_token={1}";
                Image imgUser = (Image)e.Row.Cells[0].FindControl("imgUser");
                //User Image Bind
                imgUser.ImageUrl = string.Format(m_sOAuth_Token, ((Like)e.Row.DataItem).User.Photo.SmallPhotoURL, m_oChatterRESTAPI.AccessToken);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }
        #endregion

        private void GetConsumerKeyDetails()
        {
            try
            {
                m_oUserEntities.ConsumerKey = Request.QueryString[CONST_QS_CONSUMER_KEY].ToString();
                m_oUserEntities.ConsumerSecret = Request.QueryString[CONST_QS_CONSUMER_SECRET].ToString();
                m_oUserEntities.CallBackURL = Request.QueryString[CONST_QS_CALL_BACK_URL].ToString();

                string[] arrUserInfo = Utility.GetRefreshTokenDetails(m_oUserEntities.CallBackURL, Request.QueryString[CONST_QS_WEBURL].ToString());

                //If Refresh token is there in the list then use the same refresh token
                if (!string.IsNullOrEmpty(arrUserInfo[(int)SFConstants.enUserInfo.REFRESHTOKEN]))
                {
                    m_oUserEntities.RefreshToken = arrUserInfo[(int)SFConstants.enUserInfo.REFRESHTOKEN];
                    m_oUserEntities.GroupID = arrUserInfo[(int)SFConstants.enUserInfo.GROUPID];
                    m_oUserEntities.InstanceURL = arrUserInfo[(int)SFConstants.enUserInfo.INSTANCEURL];
                }
                else
                    return;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method is used to set API information from view state
        /// </summary>
        private void SetAPIInfoFrmVS()
        {
            try
            {
                GetConsumerKeyDetails();

                Utility.LoadConfigDataFromWebConfig(m_oChatterRESTAPI);

                m_oChatterRESTAPI.ChatterAPIEndpoint = m_oUserEntities.InstanceURL;
                m_oChatterRESTAPI.AccessToken = Utility.GetPersistedAccessToken(m_oUserEntities.CallBackURL);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }
    }
}
