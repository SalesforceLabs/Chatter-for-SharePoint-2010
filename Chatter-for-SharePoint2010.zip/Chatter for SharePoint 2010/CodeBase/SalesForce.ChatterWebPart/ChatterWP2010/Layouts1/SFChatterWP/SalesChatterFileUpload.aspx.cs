﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using SalesForce.ChatterMiddleTier;
using System.Configuration;
using System.Web;

namespace SalesForce.ChatterWP2010
{
    public partial class SalesChatterFileUpload : LayoutsPageBase
    {
        SPWeb web = SPContext.Current.Web;
        SPUser currentUser = SPContext.Current.Web.CurrentUser;
        SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();
        bool IsAllowToPostFile = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            #region checks for authorization of the user.

            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                try
                {
                    // Prevent user from viewing the treeview if he is not authorizeed.
                    if (!string.IsNullOrEmpty(this.Request.QueryString["FromWebPart"])
                        && !string.IsNullOrEmpty(this.Request.QueryString["CallBackURL"]))
                    {
                        if (this.Request.QueryString["FromWebPart"].ToString() == "Yes")
                        {
                            string sCallBackURL = Request.QueryString["CallBackURL"].ToString();

                            pnlTreeView.Visible = true;

                            if (!this.IsPostBack)
                            {
                                IsAllowToPostFile = GetAllowToPostFileValue(sCallBackURL);
                                if (IsAllowToPostFile)
                                {
                                    rbtUploadFile.Enabled = true;
                                }
                                create_treeview();
                                siteStructure.CollapseAll();
                            }
                        }
                        else
                        {
                            pnlTreeView.Visible = false;
                            divError.Visible = true;
                            lblError.Text = "You are not authorised to view this page";
                            lblError.Visible = true;
                        }
                    }
                    else
                    {
                        pnlTreeView.Visible = false;
                        divError.Visible = true;
                        lblError.Text = "You are not authorised to view this page";
                        lblError.Visible = true;
                    }
                }
                catch (Exception ex)
                {
                    divError.Visible = true;
                    lblError.Text = ex.Message;
                    m_oSFChatterBAL.HandleError(ex.Message);
                }
            });

            #endregion
        }

        private bool IsUserHasAccess(SPWeb web, string userLoginName)
        {
            bool hasAccess = false;
            try
            {
                web.Site.CatchAccessDeniedException = false;
                hasAccess = web.DoesUserHavePermissions(userLoginName, SPBasePermissions.EmptyMask);
            }
            catch
            {
                hasAccess = false;
            }
            return hasAccess;
        }

        #region create treeview for site and the subsites

        //add root node to the treeview.
        public void create_treeview()
        {
            SPSite currentSiteColl;
            SPWeb currentRootWeb;
            TreeNode RootWebNode;

            try
            {
                currentSiteColl = new SPSite(web.Site.ID);
                currentRootWeb = currentSiteColl.OpenWeb();

                //get collection of sites under sitecollection/root web.
                SPWebCollection webColl = currentRootWeb.Webs;

                //Generate the tree for root node/ site collection.
                RootWebNode = new TreeNode(HttpUtility.HtmlEncode(currentRootWeb.Title));

                //Gets the login name of the user currently signed in.
                string userLoginName = currentUser.LoginName;

                //Check for the Site Collection Level Permission.
                // Add root node to the treeview uf user has access to the site collection.
                if (IsUserHasAccess(currentRootWeb, userLoginName))
                {
                    RootWebNode.SelectAction = TreeNodeSelectAction.None;
                    subsites(RootWebNode, currentRootWeb);
                    siteStructure.Nodes.Add(RootWebNode);
                    RootWebNode.ImageUrl = web.Url + "/_layouts/images/SharePointFoundation16.png";
                }
                else
                {
                    //AccessStatus.Text = "User does not has access to " + web.Title;
                }
                //Generate the tree view for each of the site under site collection and their corresponding subsites.
                childsitestructure(webColl, RootWebNode);
            }
            catch (Exception)
            {
                throw;
            }
        }

        //Add sites and subsites under the sitecollection to treeview
        private void childsitestructure(SPWebCollection collection, TreeNode parent)
        {
            try
            {
                TreeNode webNode;
                string userLoginName = web.CurrentUser.LoginName;
                foreach (SPWeb currentsite in collection)
                {
                    webNode = new TreeNode(HttpUtility.HtmlEncode(currentsite.Title));
                    webNode.SelectAction = TreeNodeSelectAction.None;
                    subsites(webNode, currentsite);

                    //Checks for the site and subsite level permission.
                    if (currentsite.DoesUserHavePermissions(userLoginName, SPBasePermissions.Open))
                    {
                        parent.ChildNodes.Add(webNode);
                        webNode.ImageUrl = web.Url + "/_layouts/images/SharePointFoundation16.png";
                    }

                    //Calls the function recursively if the current site has subsites under it.
                    if (currentsite.GetSubwebsForCurrentUser() != null)
                    {
                        SPWebCollection childsubsites1 = currentsite.Webs;
                        childsitestructure(childsubsites1, webNode);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Add folder,subfolders and files to TreeView.
        private void subsites(TreeNode WebNode, SPWeb CurrentWeb)
        {
            try
            {
                SPListCollection thislistcoll = CurrentWeb.GetListsOfType(SPBaseType.DocumentLibrary);
                TreeNode[] array1 = new TreeNode[thislistcoll.Count - 1];

                int i = 0;
                foreach (SPList thislist in thislistcoll)
                {
                    if (thislist.Hidden == true)
                        continue;
                    else if (thislist.Title.Equals("Style Library"))
                        continue;
                    else if (thislist.Title.Equals("Form Templates"))
                        continue;

                    else if (thislist.Title.Equals("Customized Reports"))
                        continue;

                    else if (thislist.Title.Equals("Site Collection Images"))
                        continue;

                    else if (thislist.Title.Equals("Site Assets"))
                        continue;

                    else if (thislist.Title.Equals("Site Pages"))
                        continue;

                    else if (thislist.Title.Equals("Master Page Gallery"))
                        continue;
                    else
                    {
                        //Check for the list or document library level permission.
                        if (thislist.DoesUserHavePermissions(currentUser, SPBasePermissions.Open))
                        {
                            if (thislist.ItemCount > 0)
                            {
                                //array[i] will contain all the out of the box and custom built document library under current site.  
                                array1[i] = new TreeNode(HttpUtility.HtmlEncode(thislist.Title));
                                if (array1[i].ChildNodes != null)
                                    array1[i].SelectAction = TreeNodeSelectAction.None;

                                array1[i].ToolTip = thislist.Title;
                                SPFolder thisfolder = thislist.RootFolder;
                                SPFolderCollection thisfoldercoll = thisfolder.SubFolders;
                                SPFileCollection thisfilecoll = thisfolder.Files;

                                //Add folder and subfolders under a doc library to the treeview.
                                GoDeep(thisfolder, array1[i], CurrentWeb); //Recursive Function Call

                                foreach (SPFile main in thisfilecoll) // will add files in folder
                                {
                                    //Checks for the file level permission.
                                    if (main.Item.DoesUserHavePermissions(SPContext.Current.Web.CurrentUser, SPBasePermissions.Open))
                                    {
                                        TreeNode myfile = new TreeNode(main.Name);
                                        myfile.Value = CurrentWeb.Url + "/" + main.Url + "#" + CurrentWeb.ID.ToString();//fileurl # web url
                                        myfile.ToolTip = CurrentWeb.Url + "/" + main.Url;
                                        //add file directly under a doc library to the treeview.
                                        array1[i].ChildNodes.Add(myfile);

                                    }
                                }
                                //Add Doc library to the treeview
                                if (array1[i] != null)
                                {
                                    WebNode.ChildNodes.Add(array1[i]);
                                    array1[i].ImageUrl = web.Url + "/_layouts/images/itdl.png";
                                }
                            }
                            i++;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Iterate through the folder to find subfolders
        public void GoDeep(SPFolder fold, TreeNode parentNode, SPWeb CurrentWeb)
        {
            SPFolderCollection foldcoll = fold.SubFolders;
            string userLoginName = web.CurrentUser.LoginName;

            try
            {
                if (foldcoll.Count != 0)
                {
                    foreach (SPFolder folder in foldcoll)
                    {
                        //Check for the folder level permission.
                        if (folder.DocumentLibrary.DoesUserHavePermissions(currentUser, SPBasePermissions.Open))
                        {
                            if (!folder.Name.Equals("Forms") && folder.Item != null)
                            {
                                TreeNode myNode = new TreeNode(HttpUtility.HtmlEncode(folder.Name));
                                myNode.ToolTip = folder.Url;
                                myNode.SelectAction = TreeNodeSelectAction.None;
                                SPFileCollection filecoll = folder.Files;

                                foreach (SPFile file in filecoll)
                                {
                                    //checks for the file level permsission.
                                    if (file.Item != null)
                                    {
                                        if (file.Item.DoesUserHavePermissions(currentUser, SPBasePermissions.ViewListItems))
                                        {
                                            TreeNode myfile = new TreeNode(file.Name);
                                            myfile.Value = CurrentWeb.Url + "/" + file.Url + "#" + CurrentWeb.ID.ToString();
                                            myfile.ToolTip = CurrentWeb.Url + "/" + file.Url;
                                            //add file under a folder to treeview.
                                            myNode.ChildNodes.Add(myfile);
                                        }
                                    }
                                }
                                //add folder under a doc library to tree view.
                                parentNode.ChildNodes.Add(myNode);
                                myNode.ImageUrl = web.Url + "/_layouts/images/folder.gif";
                                GoDeep(folder, myNode, CurrentWeb);
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion generate treeview

        /// <summary>
        /// Gets the consumer Key information
        /// </summary>
        private bool GetAllowToPostFileValue(string strCallBckURL)
        {
            SPSite currentSiteColl = null;
            SPWeb currentRootWeb = null;
            SPList oConsumerList = null;

            try
            {
                string sAllowToPostFile = ConfigurationSettings.AppSettings[SFConstants.CONST_CONFIG_KEY_ALLOW_FILE_UPLOAD];
                if (!bool.Parse(sAllowToPostFile))
                {
                    return false;
                }

                currentSiteColl = new SPSite(web.Site.ID);
                currentRootWeb = currentSiteColl.OpenWeb();

                oConsumerList = CreateListUtility.GetList(ConsumerKeyListEntity.ConsumerKeyList, currentRootWeb);
                if (oConsumerList != null)
                {
                    if (!string.IsNullOrEmpty(strCallBckURL))
                    {
                        if (strCallBckURL.Contains("?"))
                            strCallBckURL = strCallBckURL.Remove(strCallBckURL.IndexOf("?"), strCallBckURL.Length - strCallBckURL.IndexOf("?"));

                        SPListItem consumerKeyItem = CreateListUtility.GetOrgsInfoItem(oConsumerList, strCallBckURL);
                        if (consumerKeyItem != null)
                        {
                            IsAllowToPostFile = (bool)consumerKeyItem[ConsumerKeyListEntity.AllowToPostFile];
                        }
                    }
                }

                return IsAllowToPostFile;
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        private void ValidateUploadFile()
        {
            try
            {
                divError.Visible = false;
                lblError.Visible = false;
                txtFilePath.Text = siteStructure.SelectedNode.Value; //gives path of the selected node.            
                string fileurl = siteStructure.SelectedNode.Value;

                SPFile oSrcSPFile = null;
                string[] splitWebAndFileUrl = fileurl.Split('#');

                if (rbtUploadFile.Checked)
                {
                    using (SPSite srcsite = new SPSite(SPContext.Current.Site.ID))
                    {
                        using (SPWeb srcweb = srcsite.OpenWeb(new Guid(splitWebAndFileUrl[1])))
                        {
                            srcweb.AllowUnsafeUpdates = true;
                            oSrcSPFile = srcweb.GetFile(splitWebAndFileUrl[0]);

                            string file_length = oSrcSPFile.Length.ToString();
                            int intfile_length = Convert.ToInt32(file_length);

                            if (intfile_length > 26214400)
                            {
                                divError.Visible = true;
                                lblError.Text = "This file exceeds the maximum size limit of 25MB.";
                                lblError.Visible = true;
                                divFileUploadEnable.Visible = false;
                                divFileUploadDisable.Visible = true;
                            }
                            else if (intfile_length == 0)
                            {
                                divError.Visible = true;
                                lblError.Text = "File size is 0. Cannot upload.";
                                lblError.Visible = true;
                                txtFilePath.Text = "";
                                divFileUploadEnable.Visible = false;
                                divFileUploadDisable.Visible = true;
                            }
                            else 
                            {
                                divFileUploadEnable.Visible = true;
                                divFileUploadDisable.Visible = false;
                                imgbtnUpload.Attributes.Add("onclick", "javascript:BtnCreateListOk_Click();");
                            }
                        }
                    }
                }
                else
                {
                    divFileUploadEnable.Visible = true;
                    divFileUploadDisable.Visible = false;
                    imgbtnUpload.Attributes.Add("onclick", "javascript:BtnCreateListOk_Click();");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e)
        {
            try
            {
                ValidateUploadFile();
            }
            catch (Exception ex)
            {
                divError.Visible = true;
                lblError.Text = ex.Message;
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }

        protected void rbtUploadFile_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                ValidateUploadFile();
            }
            catch (Exception ex)
            {
                divError.Visible = true;
                lblError.Text = ex.Message;
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }
    }
}
