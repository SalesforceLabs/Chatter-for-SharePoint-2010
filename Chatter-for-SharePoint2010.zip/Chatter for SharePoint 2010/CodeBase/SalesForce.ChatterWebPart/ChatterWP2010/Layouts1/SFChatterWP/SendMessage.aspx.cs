﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq;
using System.Collections;
using System.Web.Script.Services;
using System.Text;
using SalesForce.ChatterMiddleTier;
using System.Net;

namespace SalesForce.ChatterWP2010
{
    public partial class SendMessage : LayoutsPageBase
    {
        #region Variables
        string sUserName = string.Empty;
        string sLoggedInUserId = string.Empty;
        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();
        #endregion Variables

        #region Events
        protected void Page_Load(object sender, EventArgs e)
        {
            string sIntanceURL = string.Empty;
            string sAccessToken = string.Empty;
            string sAutoCompleteSearchUserCount = string.Empty;            
            string sCallbackUrl = string.Empty;

            try
            {
                if (Request == null)
                {
                    return;
                }
                if (Request.QueryString[SFConstants.CONST_NAME] == null || Request.QueryString[SFConstants.CONST_ID] == null)
                {
                    return;
                }

                hdnID.Value = Request.QueryString[SFConstants.CONST_ID].ToString();
                sUserName = Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_NAME].ToString());
                sIntanceURL = Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_QS_INSTANCE_URL].ToString());
                sCallbackUrl = Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_QS_CALLBACK_URL].ToString());
                sAccessToken = Utility.GetPersistedAccessToken(sCallbackUrl);
                sAutoCompleteSearchUserCount =  Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_QS_ACSUC].ToString());
                sLoggedInUserId = Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_QS_LGUSER].ToString());
                m_oChatterRESTAPI.ChatterAPIEndpoint = sIntanceURL;
                m_oChatterRESTAPI.AccessToken = sAccessToken;
                m_oChatterRESTAPI.AutoCompleteSearchUserCount = Convert.ToInt32(sAutoCompleteSearchUserCount);

                RegisterHandlerScript(sIntanceURL, sCallbackUrl);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
                lblError.Style.Add(SFConstants.CONST_STYLE, SFConstants.CONST_DISPLAY_BLOCK);
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }

        protected void btnSend_Click(object sender, ImageClickEventArgs e)
        {
            string sUserIdList = string.Empty;
            try
            {
                sUserIdList = hdnUserIdList.Value.TrimEnd(',');
                Utility.LoadConfigDataFromWebConfig(m_oChatterRESTAPI);

                if (sUserIdList.Split(',').Length <= 9)
                {
                    m_oChatterRESTAPI.PostPrivateMessage(sUserIdList, txtBody.Text.Trim());
                    closeWindow(true);
                }
            }
            catch (WebException webex)
            {
                lblError.Text = webex.Message;
                lblError.Style.Add(SFConstants.CONST_STYLE, SFConstants.CONST_DISPLAY_BLOCK);
                m_oSFChatterBAL.HandleError(webex.Message);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message;
                lblError.Style.Add(SFConstants.CONST_STYLE, SFConstants.CONST_DISPLAY_BLOCK);
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }

        protected void btnCancel_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                closeWindow(false);
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
                lblError.Style.Add(SFConstants.CONST_STYLE, SFConstants.CONST_DISPLAY_BLOCK);
                m_oSFChatterBAL.HandleError(ex.Message);
            }
        }

        #endregion Events

        #region Methods
        /// <summary>
        /// This method will close the window on Cancel click
        /// </summary>
        private void closeWindow(bool isSent)
        {
            if (isSent)
            {
                this.Context.Response.Write("<script type='text/javascript'>alert('Your messgae has been sent.');window.frameElement.commitPopup();</script>");
            }
            else
                this.Context.Response.Write("<script type='text/javascript'>window.frameElement.commitPopup();</script>");

            this.Context.Response.End();
        }

        /// <summary>
        /// This method is used to register handler script and assing handler url to the javascript variable
        /// </summary>
        private void RegisterHandlerScript(string sInstanceUrl, string sCallbackUrl)
        {
            try
            {
                string sHandlerUrl = string.Format(SFConstants.CONST_FIVE_PARAM_FORMAT, SPContext.Current.Web.Url,
                                SFConstants.CONST_AUTOCOMPLETE_SMHANDLER, Server.UrlEncode(sCallbackUrl),
                                "&IU=", Server.UrlEncode(sInstanceUrl));

                string sJsVariables = string.Format(SFConstants.CONST_SIX_PARAM_FORMAT, "var HandlerUrl='", sHandlerUrl,
                                            "',userName='", sUserName, "', sLoggedInUserId='" + sLoggedInUserId, "', sAutoCompleteSearchUserCount=" + m_oChatterRESTAPI.AutoCompleteSearchUserCount + ";");

                if (!this.Page.ClientScript.IsStartupScriptRegistered("ChatterSendMessage"))
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ChatterSendMessage", sJsVariables, true);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion Methods
    }
}
