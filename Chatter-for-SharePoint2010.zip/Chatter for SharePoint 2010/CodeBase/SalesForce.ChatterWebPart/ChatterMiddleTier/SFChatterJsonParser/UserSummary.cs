﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get User Summary Information
    /// </summary>
    [Serializable]
    public class UserSummary
    {
        #region Private Members

        private string _name = string.Empty;
        private string _id = string.Empty;
        private Photo _photo = null;
        private Reference _mySubscription = null;
        private string _type = string.Empty;
        private bool _isChatterGuest = false;

        // Comment out unwanted property
        //private string _companyName = string.Empty;
        //private bool _isChatterGuest = false;
        //private string _firstname = string.Empty;
        //private string _lastname = string.Empty;
        //private string _url = string.Empty;
        //private string _title = string.Empty;
        #endregion

        #region Properties

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

       
        

        public Photo Photo
        {
            get
            {
                return _photo;
            }
            set
            {
                _photo = value;
            }
        }


        public Reference MySubscription
        {
            get
            {
                return _mySubscription;
            }
            set
            {
                _mySubscription = value;
            }
        }

        public string Type
        {
            get
            {
                return _type; 
            }
            set
            {
                _type = value;
            }
        }

        public bool IsChatterGuest
        {
            get
            {
                return _isChatterGuest;
            }
            set
            {
                _isChatterGuest = value;
            }
        }

        //public string CompanyName
        //{
        //    get
        //    {
        //        return _companyName;
        //    }
        //    set
        //    {
        //        _companyName = value;
        //    }
        //}

        //public bool IsChatterGuest
        //{
        //    get
        //    {
        //        return _isChatterGuest;
        //    }
        //    set
        //    {
        //        _isChatterGuest = value;
        //    }
        //}

        //public string FirstName
        //{
        //    get
        //    {
        //        return _firstname;
        //    }
        //    set
        //    {
        //        _firstname = value;

        //    }
        //}

        //public string LastName
        //{
        //    get
        //    {
        //        return _lastname;
        //    }
        //    set
        //    {
        //        _lastname = value;
        //    }
        //}

        //public string URL
        //{
        //    get
        //    {
        //        return _url;
        //    }
        //    set
        //    {
        //        _url = value;
        //    }

        //}
        //public string Title
        //{
        //    get
        //    {
        //        return _title;
        //    }
        //    set
        //    {
        //        _title = value;
        //    }
        //}

      

        #endregion


    }
}