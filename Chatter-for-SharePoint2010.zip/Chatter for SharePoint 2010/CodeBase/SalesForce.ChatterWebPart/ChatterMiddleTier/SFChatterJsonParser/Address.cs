﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{

    /// <summary>
    /// Class is used to get/set Class information
    /// </summary>
    [Serializable]
    public class Address
    {
        #region Private Memebers

        private string _state = string.Empty;
        private string _country = string.Empty;
        private string _city = string.Empty;
        private string _zip = string.Empty;
        private string _street = string.Empty;


        #endregion

        #region

        public string State
        {
            get
            {
                return _state;
            }
            set
            {
                _state = value;
            }
        }

        public string Country
        {
            get
            {
                return _country;
            }
            set
            {
                _country = value;
            }
        }

        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }

        public string Zip
        {
            get
            {
                return _zip;
            }
            set
            {
                _zip = value;
            }
        }

        public string Street
        {
            get
            {
                return _street;
            }
            set
            {
                _street = value;
            }
        }

        #endregion
    }
}