﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Comemnt page information
    /// </summary>
    [Serializable]
    public class CommentPage
    {
        #region Private Members

        private int _total = 0;
        private string _nextPageURL = string.Empty;
        private Comments[] _comments;

        // Comment out unwanted property
        //private string _currentPageURL = string.Empty;
        #endregion

        #region Properties

        public int Total
        {
            get
            {
                return _total;
            }
            set
            {
                _total = value;
            }
        }

        public Comments[] Comments
        {
            get
            {
                return _comments;
            }
            set
            {
                _comments = value;
            }
        }

        public string NextPageURL
        {
            get
            {
                return _nextPageURL;
            }
            set
            {
                _nextPageURL = value;
            }
        }

        //public string CurrentPageURL
        //{
        //    get
        //    {
        //        return _currentPageURL;
        //    }
        //    set
        //    {
        //        _currentPageURL = value;
        //    }
        //}

        #endregion
    }
}