﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Group Information
    /// </summary>
    [Serializable]
    public class Group
    {
        #region private members
        private string _name = string.Empty;
        private string _id = string.Empty;
        private string _description = string.Empty;
        private Photo _photo = null;
        private Reference _mySubscription = null;
        private int _memberCount = 0;

        // Comment out unwanted property
        //private bool _canHaveChatterGuests = false;
        //private string _myRole = string.Empty;
        //private string _type = string.Empty;
        //private string _visibilty = string.Empty;
        //private string _url = string.Empty;
        #endregion

        #region Properties

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

       

        public Photo Photo
        {
            get
            {
                return _photo;
            }
            set
            {
                _photo = value;
            }
        }
        

        public Reference MySubscription
        {
            get
            {
                return _mySubscription;
            }
            set
            {
                _mySubscription = value;
            }
        }

        public int MemberCount
        {
            get
            {
                return _memberCount;
            }
            set
            {
                _memberCount = value;
            }
        }
       
        //public string Type
        //{
        //    get
        //    {
        //        return _type;
        //    }
        //    set
        //    {
        //        _type = value;
        //    }
        //}
        //public string URL
        //{
        //    get
        //    {
        //        return _url;
        //    }
        //    set
        //    {
        //        _url = value;
        //    }
        //}
        //public string Visibility
        //{
        //    get
        //    {
        //        return _visibilty;
        //    }
        //    set
        //    {
        //        _visibilty = value;
        //    }
        //}
      

        //public bool CanHaveChatterGuests
        //{
        //    get
        //    {
        //        return _canHaveChatterGuests;
        //    }
        //    set
        //    {
        //        _canHaveChatterGuests = value;
        //    }
        //}

        //public string MyRole
        //{
        //    get
        //    {
        //        return _myRole;
        //    }
        //    set
        //    {
        //        _myRole = value;
        //    }
        //}
        #endregion
    }
}