﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class SubscriptionPage
    {
        #region Private Members

        
        private string _nextPageUrl = string.Empty;
        private string _previousPageUrl = string.Empty;
        private Subscription[] _subscriptions = null;
        private int _total = -1;
        private string _currentPageUrl = string.Empty;
        #endregion

        #region Properties

        public string CurrentPageUrl
        {
            get
            {
                return _currentPageUrl;
            }
            set
            {
                _currentPageUrl = value;
            }
        }

        public string NextPageUrl
        {
            get
            {
                return _nextPageUrl;
            }
            set
            {
                _nextPageUrl = value;
            }
        }

        public string PreviousPageUrl
        {
            get
            {
                return _previousPageUrl;
            }
            set
            {
                _previousPageUrl = value;
            }
        }

        public Subscription[] subscriptions
        {
            get
            {
                return _subscriptions;
            }
            set
            {
                _subscriptions = value;
            }
        }

        public int Total
        {
            get
            {
                return _total;
            }
            set
            {
                _total = value;
            }
        }
        #endregion
    }
}
