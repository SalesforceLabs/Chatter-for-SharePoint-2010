﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Like information
    /// </summary>
    [Serializable]
    public class Like
    {
        #region  Private Members

        private string _id = string.Empty;
        private UserSummary _user = null;
        private string _url = string.Empty;

        #endregion

        #region Property

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public UserSummary User
        {
            get
            {
                return _user;
            }
            set
            {
                _user = value;
            }
        }

        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }

        #endregion
    }
}