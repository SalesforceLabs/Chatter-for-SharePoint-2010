﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{

    [Serializable]
    public class Mention : MsgSegForMention
    {
        #region Private Memebers

        private string _id = string.Empty;

        #endregion

        #region Properties

       
        public string id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        #endregion
    }
}
