﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{

    /// <summary>
    /// Class is used to get/set Group Member Page
    /// </summary>
    [Serializable]
    public class GroupMemberPage
    {
        #region Private Members
        private Group[] _members = null;
        private string _nextPageURL = string.Empty;

        // Comment out unwanted property
        //private Reference _myMembership = null;
        //private int _total = 0;
        //private string _currentPageURL = string.Empty;
        //private string _previousPageURL = string.Empty;

        #endregion

        #region Properties

        public Group[] Members
        {
            get
            {
                return _members;
            }
            set
            {
                _members = value;
            }
        }

     

        public string NextPageURL
        {
            get
            {
                return _nextPageURL;
            }
            set
            {
                _nextPageURL = value;
            }
        }

        //public string CurrentPageURL
        //{
        //    get
        //    {
        //        return _currentPageURL;
        //    }
        //    set
        //    {
        //        _currentPageURL = value;
        //    }
        //}

        //public int TotalMemberCount
        //{
        //    get
        //    {
        //        return _total;
        //    }
        //    set
        //    {
        //        _total = value;
        //    }
        //}
        //public string PreviousPageURL
        //{
        //    get
        //    {
        //        return _previousPageURL;
        //    }
        //    set
        //    {
        //        _previousPageURL = value;
        //    }
        //}
        //public Reference MyMembership
        //{
        //    get
        //    {
        //        return _myMembership;
        //    }
        //    set
        //    {
        //        _myMembership = value;
        //    }
        //}

        #endregion
    }
}