﻿using System;
using System.Collections.Generic;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class FileDetails
    {

        #region Private Members

        private string _contentSize = string.Empty;
        private string _contentUrl = string.Empty;
        private string _description = string.Empty;
        private string _fileType = string.Empty;
        private string _flashRenditionStatus = string.Empty;
        private string _id = string.Empty;
        private string _modifiedDate = string.Empty;
        private string _origin = string.Empty;
        private UserSummary _owner = null;
        private string _pdfRenditionStatus = string.Empty;
        private string _title = string.Empty;
        private string _type = string.Empty;
        private string _url = string.Empty;
        private string _versionNumber = string.Empty;
        
        #endregion 


        #region Properties

        public string ContentSize
        {
            get
            {
                return _contentSize;
            }
            set
            {
                _contentSize = value;
            }
        }

        public string ContentUrl
        {
            get
            {
                return _contentUrl;
            }
            set
            {
                _contentUrl = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        public string FileType
        {
            get
            {
                return _fileType;
            }
            set
            {
                _fileType = value;
            }
        }

        public string FlashRenditionStatus
        {
            get
            {
                return _flashRenditionStatus;
            }
            set
            {
                _flashRenditionStatus = value;
            }
        }

        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string ModifiedDate
        {
            get
            {
                return _modifiedDate;
            }
            set
            {
                _modifiedDate = value;
            }
        }

        public string Origin
        {
            get
            {
                return _origin;
            }
            set
            {
                _origin = value;
            }
        }

        public UserSummary Owner
        {
            get
            {
                return _owner;
            }
            set
            {
                _owner = value;
            }
        }

        public string PdfRenditionStatus
        {
            get
            {
                return _pdfRenditionStatus;
            }
            set
            {
                _pdfRenditionStatus = value;
            }
        }

        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public string Url
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }
        
        public string VersionNumber
        {
            get
            {
                return _versionNumber;
            }
            set
            {
                _versionNumber = value;
            }
        }

        #endregion


    }
}
