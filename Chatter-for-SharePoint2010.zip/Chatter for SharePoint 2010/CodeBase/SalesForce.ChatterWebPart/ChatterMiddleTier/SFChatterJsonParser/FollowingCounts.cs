﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    public class FollowingCounts
    {
        #region Private Members

        private int _people = 0;
        private int _records = 0;
        private int _total = 0;

        #endregion

        #region Properties

        public int People
        {
            get
            {
                return _people;
            }
            set
            {
                _people = value;
            }
        }

        public int Records
        {
            get
            {
                return _records;
            }
            set
            {
                _records = value;
            }
        }

        public int Total
        {
            get
            {
                return _total;
            }
            set
            {
                _total = value;
            }
        }

        #endregion
    }
}
