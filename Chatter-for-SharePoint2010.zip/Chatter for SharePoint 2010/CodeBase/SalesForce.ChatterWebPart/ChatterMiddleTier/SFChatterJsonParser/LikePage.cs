﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// class is used to like page information
    /// </summary>
    [Serializable]
    public class LikePage
    {
        #region Private Memebers

        private int _total = 0;
        
        private string _nextPageURL = string.Empty;
        private Like[] _likes = null;
        private Reference _myLike = null;

        // Comment out unwanted property
        //private string _currentPageURL = string.Empty;
        //private string _previousPageURL = string.Empty;
        #endregion

        #region Properties

        public int Total
        {
            get
            {
                return _total;
            }
            set
            {
                _total = value;
            }
        }

       

        public string NextPageURL
        {
            get
            {
                return _nextPageURL;
            }
            set
            {
                _nextPageURL = value;
            }

        }

        public Like[] Likes
        {
            get
            {
                return _likes;
            }
            set
            {
                _likes = value;
            }

        }

        public Reference MyLike
        {
            get
            {
                return _myLike;
            }
            set
            {
                _myLike = value;
            }
        }

        //public string CurrentPageURL
        //{
        //    get
        //    {
        //        return _currentPageURL;
        //    }
        //    set
        //    {
        //        _currentPageURL = value;
        //    }
        //}
        //public string PreviousPageURL
        //{
        //    get
        //    {
        //        return _previousPageURL;
        //    }
        //    set
        //    {
        //        _previousPageURL = value;
        //    }
        //}

        #endregion
    }
}