﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Feed Body information
    /// </summary>
    [Serializable]
    public class FeedBody
    {
        #region private members

        private string _text = string.Empty;

        private MessageSegments[] _messageSegments;

        #endregion

        #region Properties


        public string Text
        {
            get
            {
                return _text;
            }
            set
            {
                _text = value;
            }
        }

        public MessageSegments[] MessageSegments
        {
            get
            {
                return _messageSegments;
            }
            set
            {
                _messageSegments = value;
            }
        }

        #endregion
    }
}