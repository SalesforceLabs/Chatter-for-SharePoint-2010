﻿using System;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// This class is used for Constants
    /// </summary>
    public static class SFConstants
    {
        #region All Constants

        public const string CONST_2007_Solution_Id = "28d97ede-3019-450c-b332-c79c403a11e0";
        public const string CONST_2010_Solution_Id = "f7fc43b3-4848-49df-b645-fa10d278f2ce";

        public const string CONST_sOnKeyDown = "checkFeedLength({0},{1});";
        public const string CONST_sOAuth_Token = "{0}?oauth_token={1}";
        public const string CONST_sSingleLineTextClick = "singleLinecomment_click('{0}','{1}','{2}','{3}','{4}');";
        public const string CONST_sLnkCommentClick = "return LnkComment_click('{0}','{1}','{2}','{3}','{4}','{5}');";        
        public const string CONST_sOnKeyDownTbComment = "check_length('{0}','{1}','{2}','{3}');";
        public const string CONST_sOnClickTbComment = "tbComment_Click('{0}','{1}','{2}','{3}');";
        public const string CONST_MouseToolTip_Format = "MouseToolTip('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}');";
        public const string CONST_SetDivAfterClick_Format = "setDivPositionAfterClick('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}');";
        public const string CONST_Show_DeleteImg_Format = "ShowDeleteImage('{0}');";
        public const string CONST_Hide_DeleteImg_Format = "HideDeleteImage('{0}');";
        public const string CONST_Confirm_Format = "return confirm('{0}');";
        public const string CONST_sDownload_Dialog_Format = "javascript:OpenDownloadDialog('{0}')";
        public const string CONST_CHATTER_CALLBACK_URL = "_layouts/SFChatterWP/oAuthLoginPage.aspx";
        public const string CONST_State_Format = "{0}?UID={1}";
        
        public const string CONST_sShareWithGrp = "Share with {0}";
        public const string CONST_sShowComments = "Show All {0} Comments";
        public const string CONST_sGroupAccessErr = "Error: You do not have permission to view the feeds from {0}.</br> Please contact your administrator.";
        public const string CONST_FileSizeErr = "This file exceeds the maximum size limit of 100MB.";
        public const string CONST_FilePost = "Posted a File.";
        public const string CONST_LinkPost = "posted a link.";
        public const int CONST_TimeInterval = 5400000;
        public const string CONST_GROUPACCESSERR = "Error: You do not have permission to view the feeds from {0}.</br> Please contact your administrator.";
        public const string CONST_INVALIDGROUPERR = "Error: Invalid group(s) has been configured.</br> Please contact your administrator.";
        public const string CONST_LOGIN_SESSION_EXPIRATION_ERR_MSG = "Your login session has expired. Please login again.";
        public const string CONST_TOKEN_EXPIRATION_ERR = "expired access/refresh token";
        public const string CONST_GROUPSELECTMSG = "Please enter a search value </br> for Group Name";
        public const string CONST_ACCESS_DENIED = "You do not have permission to do this.";
        public const string CONST_SM_NORESULT_FORMAT = "NO USER\\*\\We can't find any Chatter users with {0}  in their name.";
        public const string CONST_NAME = "Name";
        public const string CONST_ID = "ID";
        public const string CONST_MOUSEOVER = "onmouseover";
        public const string CONST_MOUSEOUT = "onmouseout";
        public const string CONST_HTTP = "http";
        public const string CONST_AUTOCOMPLETE_HANDLER = "/_layouts/SFChatterWP/GetUsers.ashx?CU=";
        public const string CONST_AUTOCOMPLETE_SMHANDLER = "/_layouts/SFChatterWP/GetSMUsers.ashx?CU=";
        public const string CONST_APPEND_IMG_FORMAT = "ImgAppend='?oauth_token=";
        public const string CONST_ONE_COMMENT = "Show 1 Comment";
        public const string CONST_SHOW_MORE_FEED_ID = "ShowMoreFeedID";

        public const string CONST_DEFAULTMESSAGE = "What are you working on?";
        public const string CONST_ACCESS_TOKEN = "AccessToken";
        public const string CONSTANT_VS_CONFIG_DATA = "CONFIG_DATA_ARRAY";
        public const string CONST_CTRL_GVCOMMENTLIST = "gvCommentList";
        public const string CONST_CTRL_LBLLIKES = "lblLikes";
        public const string CONST_CTRL_LBLCREATEDDATE = "lblCreatedDate";
        public const string CONST_CTRL_DIVACTIVITY = "divActivity";
        public const string CONST_CTRL_HDNFEEDID = "hdnFeedId";
        public const string CONST_CTRL_HDNROWINDEX = "hdnRowIndex";
        public const string CONST_CTRL_LINKCOMMENT = "linkComment";
        public const string CONST_CTRL_TBCOMMENT = "tbComment";
        public const string CONST_CTRL_TXTSINGLELINE = "txtSLComment";
        public const string CONST_CTRL_BTNCOMMENT = "imgBtnComment";
        public const string CONST_CTRL_IMAGECOMMENTNEW = "imgCommentNew";
        public const string CONST_CTRL_FILEINFO = "divFileInfo";
        public const string CONST_CTRL_LINKSHOWALLCOMMENTS = "linkShowAllComments";
        public const string CONST_CTRL_LINKLIKE = "linkLike";
        public const string CONST_CTRL_LINKUNLIKE = "linkUnlike";
        public const string CONST_CTRL_LBLLENGTHERROR = "lblLengthError";        
        public const string CONST_CTRL_LBLFILEDESC = "lblFileDesc";
        public const string CONST_CTRL_IMGFILE = "imgFile";
        public const string CONST_CTRL_IMGPIC = "imgPic";
        public const string CONST_CTRL_IMGGROUPICON = "imgGroupIcon";
        public const string CONST_CTRL_LBLGROUPICON = "lblGroupIcon";
        public const string CONST_CTRL_FEEDERROR = "lblFeedError";
        public const string CONST_CTRL_LBLPARENT = "lblParent";
        public const string CONST_CTRL_LBLACTOR = "lblActor";
        public const string CONST_CTRL_LBLAUTHOR = "lblAuthor";
        public const string CONST_CTRL_SHOW_ALL_COMMENTS = "divShowAllComments";
        public const string CONST_CTRL_LIKE = "divLike";
        public const string CONST_CTRL_COMMENTBOX = "divCBox";
        public const string CONST_CTRL_SINGLE_LINE_COMMENT = "dslComment";
        public const string CONST_CTRL_DIV_COMMENT_LIST = "divCommentList";
        public const string CONST_CTRL_DIV_DISABLE_COMMENT = "divDComment";
        public const string CONST_CTRL_DIV_ENABLE_COMMENT = "divEComment";
        public const string CONST_CTRL_LBLLENGTH_ERROR = "lblLengthError";
        public const string CONST_CTRL_DIVLINKINFO = "divLinkInfo";
        public const string CONST_CTRL_LBLLINKNAME = "lblLinkName";
        public const string CONST_CTRL_LBLLINKURL = "lblLinkUrl";
        public const string CONST_CTRL_LITGROUPID = "litGroupID";
        public const string CONST_CTRL_NEXT = "lnkNext";
        public const string CONST_CTRL_PREVIOUS = "lnkPrevious";
        public const string CONST_CTRL_LBLMEMBERCOUNT = "lblMemberCount";
        public const string CONST_CTRL_IMGGROUP = "imgGroup";
        public const string CONST_CTRL_LBLDESCRIPTION = "lblDescription";
        public const string CONST_CTRL_LNKFILTER = "lnkFilter";
        public const string CONST_CTRL_LNKFILENAME = "lnkFileName";
        public const string CONST_CTRL_IMGTICK = "imgTick";
        public const string CONST_CTRL_SPAN_FEED = "spanFeed";
        public const string CONST_CTRL_SPAN_COMMENT = "spanComment";        
        public const string CONST_CTRL_IMGCOMMENT = "imgComment";
        public const string CONST_CTRL_DVEXPAND = "dvExpand";
        public const string CONST_USERS_COMMENT = "users_comment";
        public const string CONST_CLASS = "class";
        public const string CONST_HEIGHT = "height";
        public const string CONST_AUTO = "auto";                
        public const string CONST_QS_CODE = "code";
        public const string CONST_QS_ERROR = "error";
        public const string CONST_EVENT_ON_KEY_DOWN = "onKeyDown";
        public const string CONST_EVENT_ON_KEY_UP = "onKeyUp";
        public const string CONST_EVENT_ON_CLICK = "onclick";
        public const string CONST_COMMENT_TEXT = "Write a comment...";
        public const string CONST_UNLIKE = "Unlike";
        public const string CONST_LIKE = "Like";
        public const string CONST_ME = "Me";
        public const string CONST_MYCHATTER = "My Chatter";
        public const string CONST_SHOWALL = "ShowAll";
        public const string CONST_PREVIOUS = "Previous";
        public const string CONST_NEXT = "Next";
        public const string CONST_COMMENT_CLICK = "CommentLink";
        public const string CONST_VS_GLOBALENTITIES = "GLOBALENTITIES";
        public const string CONST_VS_GROUPLIST = "GROUPLIST";
        public const string CONST_VISIBILITY_AUTHENTICATED = "Authenticated";
        public const string CONST_VISIBILITY_ADMIN = "Administrator";
        public const string CONST_VISIBILITY_LOAD = "Load";
        public const string CONST_VISIBILITY_EXCEPTIONS = "Exceptions";
        public const string CONST_VISIBILITY_GRPSELECTION = "GroupSelection";
        public const string CONST_VISIBILITY_OAUTH = "OrgException";
        public const string CONST_VISIBILITY_NOGRPSELECTION = "NoGroupSelection";
        public const string CONST_VS_FEEDDATA = "FeedData";
        public const string CONST_VS_WEBRESPONSE_ERR = "WebResponseErr";
        public const string CONST_FILE_REMOVED_MSG = "The file is no longer available.";
        public const string CONST_ERR_CONNECTION = "Error: Please try after sometime, connection with server is getting established.";
        public const string CONST_ERR_SHARE = "Error: Please try after sometime, your last operation failed to complete successfully.";
        public const string CONST_ERR_STD = "Error: Please contact your administrator, ";
        public const string CONST_ERR_STANDARD = "Error: There is some problem, Please contact your administrator.";
        public const string CONST_DELETE_POST = "Are you sure you want to delete this post?";
        public const string CONST_DELETE_COMMENT = "Are you sure you want to delete this comment?";
        public const string CONST_REQ_GROUP_ERR = "Error: Please enter valid Group.";
        public const string CONST_VALID_GROUP_ERR = "Error: Please enter atleast 2 characters to search Group.";
        public const string CONST_NO_MATCH_FOUND = "Error: No match found.";           
        public const string CONST_CTRL_HDNCOMMENTID = "hdnCommentId";
        public const string CONST_CTRL_HDNPOSTINDEX = "hdnPostIndex";
        public const string CONST_CTRL_LBLPOSTINDEX = "lblPostIndex";
        public const string CONST_CTRL_BTNDELETECOMMENT = "btnDeleteComment";
        public const string CONST_CTRL_BTNDELETEPOST = "btnDeletePost";
        public const string CONST_CTRL_LBLCOMMENTINDEX = "lblCommentIndex";
        public const string CONST_CSS_TABSELECTED = "tab_selected";
        public const string CONST_CSS_NORMAL = "tab_normal";
        public const string CONST_DISPLAY_BLOCK = "display: block;";
        public const string CONST_DISPLAY_NONE = "display: none;";
        public const string CONST_STYLE = "style";
        public const string CONST_NO_UPDATES = "There are no updates.";
        public const string CONST_ALL_UPDATES  = "Search Results <br/> Updates for all objects";
        public const string CONST_TEXT = "Text";
        public const string CONST_LINK = "Link";
        public const string CONST_HASHTAG = "Hashtag";
        public const string CONST_MENTION = "Mention";
        public const string CONST_ATTR_BLANK = "_blank";
        public const string CONST_BATCH_ID = "id";
        public const string CONST_BATCH_PHONENUMBERS = "phoneNumbers";
        public const string CONST_BATCH_NUMBER = "number";
        public const string CONST_BATCH_TYPE = "type";
        public const string CONST_CSS_GROUP_MRU = "group_Mru";
        public const string CONST_MSG_NOT_SHOWN_SECURITY = "Not shown for security reasons";
        public const string CONST_QS_UID = "UID";
        public const string CONST_QS_STATE = "state";
        public const string CONST_QS_CALL_BACK_URL = "CallBackURL"; 

        public const string CONST_ENCRYPTDECRYPT_KEYSIZE_ERR_MSG = "EncryptDecryptKeySize";

        public const string CONST_OTHER_USER_LOGIN = "OtherUser";
        public const string CONST_BTNLOGIN = "BtnLoginClick";

        public const string CONST_GENERIC_ERR_MSG = "Generic";
        public const string CONST_POSTDELETED_ERR_MSG = "PostDeleted";
        public const string CONST_STORAGE_LIMIT_ERR_MSG = "STORAGE_LIMIT_EXCEEDED";
        public const string CONST_SUBMITCOMMENT_ERR_MSG = "SubmitComment";

        //All Event names
        public const string CONST_EVENT_PAGELOAD = "Page_Load";
        public const string CONST_EVENT_DDL_INDEX_CHANGE = "ddlSelectGroup_SelectedIndexChanged";
        public const string CONST_EVENT_TMR_AUTO = "tmrAutoRefresh_Click";
        public const string CONST_EVENT_TMR_ACCESSTOKEN = "tmrAccessToken_Tick";
        public const string CONST_EVENT_IMGBTNSEARCHGROUP_CLICK = "imgBtnSearchGroup_Click";
        public const string CONST_EVENT_GVSEARCHGROUP_ONCOMMAND = "gvSearchGroup_OnCommand";
        public const string CONST_EVENT_BTNCOMMENT_CLICK = "btnComment_Click";
        public const string CONST_EVENT_IMGBTNSHARE_CLICK = "imgbtnShare_Click";
        public const string CONST_EVENT_BTNLOGIN_CLICK = "btnLogin_Click";
        public const string CONST_EVENT_BTNSWITCHUSER_CLICK = "btnSwitchUser_Click";
        public const string CONST_EVENT_LNKLOGOUT_CLICK = "lnkLogOut_Click";
        public const string CONST_EVENT_BTNSHOWMOREFEEDS_CLICK = "btnShowMoreFeeds_Click";
        public const string CONST_EVENT_BTNDELETECOMMENT_CLICK = "btnDeleteComment_Click";
        public const string CONST_EVENT_BTNDELETEPOST_CLICK = "btnDeletePost_Click";
        public const string CONST_EVENT_GROUPNAME_CLICK = "GroupName_Click";
        public const string CONST_EVENT_COMMAND_CLICK = "command_Click";
        public const string CONST_EVENT_IMGBTNSEARCH_CLICK = "imgBtnSearch_Click";
        public const string CONST_EVENT_LNKHASHTAG_CLICK = "lnkHashtag_Click";
        public const string CONST_EVENT_LNKFOLLOWUNFOLLOWUSER_CLICK = "lnkFollowUnFollowUser_Click";
        public const string CONST_EVENT_LNKSTATUSCLEAR_CLICK = "lnkStatusClear_Click";
        public const string CONST_EVENT_RPTFEEDFILTER_ITEMCOMMAND = "rptFeedFilter_ItemCommand";
        public const string CONST_EVENT_IMGSEARCHCLEARBUTTON_CLICK = "imgSearchClearButton_Click";
        public const string CONST_EVENT_IMGSEARCHCLEARFEEDBUTTON_CLICK = "imgSearchClearFeedButton_Click";


        public const string CONST_EVENT_GETPHOTOURL = "GetPhotoURL";
        public const string CONST_EVENT_GETFEEDTEXTASHTML = "GetFeedTextAsHtml";
        
        //End all event names

        //Handler Constants
        public const string CONST_QS_INSTANCE_URL = "IU";
        public const string CONST_QS_ACCESS_TOKEN = "AT";
        public const string CONST_QS_CONSUMER_KEY = "CK";
        public const string CONST_QS_CALLBACK_URL = "CU";
        public const string CONST_QS_FEED_ID = "FeedId";
        public const string CONST_QS_ACSUC = "ACSUC";
        public const string CONST_QS_LGUSER = "LGUSER";
        public const string CONST_MENTION_HELP = "Type Someone's name to notify them about this update";
        public const string CONST_MENTION_NOMATCH = "No matching names";
        public const string CONST_HASH_HELP = "Type a word to link to all posts and comments on this topic";
        public const string CONST_NO_IMG = "/_layouts/images/SFChatterWP/file_not_available.png";
        public const string CONST_NO_RESULT = "NO RESULT";
        public const string CONST_DOWNLOAD_APIURL = "APIURL";
        public const string CONST_DOWNLOAD_MIMETYPE = "MIMETYPE";
        public const string CONST_DOWNLOAD_FILETITLE = "FILETITLE";
        //End Handler Constants

        //Constant for logger
        public const string CONST_CHATTER = "Chatter";

        //Like Text Constants
        public const string CONST_LikeOneUserFomrat = "{0} {1}.";
        public const string CONST_LikeTwoUserFormat = "{0} and {1} {2}.";
        public const string CONST_LikeThreeUserFormat = "{0}, {1} and {2} {3}.";
        public const string CONST_UNameFormat = "<font color='#015ba7'>{0}</font>";        
        public const string CONST_YOU = "You";
        public const string CONST_LikeMoreUserFormat = "{0}, {1} and {2} {3}.";        
        public const string CONST_OthersFormat = "<a href=\"javascript:OpenDialogForUserList('{0}','{1}','{2}', '{3}');\">{4} others</a>";
        public const string CONST_SINGLE_GROUP_FORMAT = "1 Member";
        public const string CONST_MULTIPLE_GROUP_FORMAT = "{0} Members";
        public const string CONST_FILTER_FORMAT = "{0}{1}?pageSize=20";
        public const string m_sSearchFeeds = "{0}{1}/feed-items?q={2}&pageSize=20";

        public const string m_sMentionUrl = "{0}/{1}";

        //Web Config Constants
        public const string CONST_APP_SETTINGS_VALUE_FORMAT= "<add key=\"{0}\" value=\"{1}\"/>";
        public const string CONST_APP_SETTINGS_NAME_FORMAT = "add[@key='{0}']";
        public const string CONST_APP_SETTINGS_XPATH = "configuration/appSettings";
        public const string CONST_WEB_CONFIG_MODIFICATION_OWNER = "SFChatter";

        public const string CONST_CONFIG_KEY_ENCRYPT_DECRYPT_KEY = "SFChatter_EncryptDecryptKey";
        public const string CONST_CONFIG_KEY_CALLBACK_URL = "SFChatter_CallBackURL";
        public const string CONST_CONFIG_KEY_ABI_BASE = "SFChatter_APIBase";
        public const string CONST_CONFIG_KEY_CONSUMER_KEY = "SFChatter_ConsumerKey";
        public const string CONST_CONFIG_KEY_CONSUMER_SECRET = "SFChatter_ConsumerSecret";
        public const string CONST_CONFIG_KEY_AUTHORIZATION_URL = "SFChatter_AuthorizationURL";
        public const string CONST_CONFIG_KEY_ACCESS_TOKEN_URL = "SFChatter_AccessTokenURL";
        public const string CONST_CONFIG_KEY_AUTO_REFRESH_TIMER = "SFChatter_AutoRefreshTimer";
        public const string CONST_CONFIG_KEY_AUTO_COMPLETE_COUNT = "SFChatter_AutoCompleteCount";
        public const string CONST_CONFIG_KEY_ALLOW_FILE_UPLOAD = "SFChatter_AllowFileUpload";


        public const string CONST_CONFIG_DEFAULT_ENCRYPT_DECRYPT_KEY = "ChatterConnector";
        public const string CONST_CONFIG_DEFAULT_ABI_BASE = "/services/data/v23.0/chatter";
        public const string CONST_CONFIG_DEFAULT_AUTHORIZATION_URL = "https://login.salesforce.com/services/oauth2/authorize";
        public const string CONST_CONFIG_DEFAULT_ACCESS_TOKEN_URL = "https://login.salesforce.com/services/oauth2/token";
        public const string CONST_CONFIG_DEFAULT_AUTO_REFRESH_TIMER = "180000";
        public const string CONST_CONFIG_DEFAULT_AUTO_COMPLETE_COUNT = "50";
        public const string CONST_CONFIG_DEFAULT_ALLOW_FILE_UPLOAD = "false";
        
        public const string CONST_CONFIG_ADD = "add";
        public const string CONST_CONFIG_KEY = "key";
        public const string CONST_CONFIG_VALUE = "value";
        public const string CONST_ADMIN_ERR_MSG = "Admin";



        //All global formatters
        public const string CONST_TWO_PARAM_FORMAT = "{0}{1}";
        public const string CONST_THREE_PARAM_FORMAT = "{0}{1}{2}";
        public const string CONST_FIVE_PARAM_FORMAT = "{0}{1}{2}{3}{4}";
        public const string CONST_SIX_PARAM_FORMAT = "{0}{1}{2}{3}{4}{5}";

        public const string CONST_VS_ALL_USER_LIST = "AllUserList";
        public const string CONST_VS_USER_BATCH_DETAIL = "UserBatchDetails";
        public const string CONST_FOLLOW = "Follow";
        public const string CONST_UNFOLLOW = "UnFollow";
        public const string CONST_YES = "yes";
        public const string CONST_NO = "no"; 
        #endregion All Constants

        #region All Enums
        /// <summary>
        /// This Enum is used for the Refresh Token and GroupID index
        /// </summary>
        public enum enUserInfo { REFRESHTOKEN = 0, GROUPID = 1, INSTANCEURL = 2 };

        /// <summary>
        /// This Enum is used for the Config members index
        /// </summary>
        public enum enConfigData
        {
            AccessTokenAPI = 0,
            ChatterAPIBase = 1,
            AuthorizeAPI = 2,
            AutoRefreshTimer = 3,
            ChatterAPIEndpoint = 4,
            AutoCompleteSearchUserCount = 5
        }

        /// <summary>
        /// 
        /// </summary>
        public enum enControlVisibility
        {
            Authenticated = 0,
            Administrator = 1,
            Load = 2,
            Exceptions = 3,
            GroupSelection = 4,
            NoGroupSelection = 5,
            OrgException = 6,
            AutoRefreshTimer = 7,
            SingleGroupConfigured = 8,
            GroupAccessErr = 9,
            MultipleGroupAccessErr = 10,
            AllChatterSelection = 11,
            ToMeSelection = 12,
            InValidConsumerKey =13,
            ValidConsumerKey =14,
            SwitchUser =15 ,
            SearchGroupErr =16,
            ShowGroupSearchResult=17,
            GroupPageNavigation=18,
            FeedSearch = 19,
            FilterNoUpdates = 20,
            FeedSearchNoMatch = 21,
            AutoRefreshTimerErr = 22,
            LogOut = 23
        }

        /// <summary>
        /// 
        /// </summary>
        public enum enSPFilePath
        {
            FilePath = 0,
            SPWebGUID = 1,
            UploadFileOrLink = 2
        }

        /// <summary>
        /// 
        /// </summary>
        public enum enFeedState
        {
            FilterChange = 0,
            NewFeed = 1,
            ShowMoreFeed = 2,
            AutoRefresh = 3,
            GroupChange = 4
        }

        /// <summary>
        /// 
        /// </summary>
        public enum enFilterType
        {
            Filter = 0,
            Search = 1
        }


        #endregion
    }
}
