﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using SalesForce.ChatterMiddleTier;
using System.Net;
using System.IO;

namespace SalesForce.ChatterWP2010.Layouts1.SFChatterWP
{
    public partial class Download : LayoutsPageBase
    {

        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();

        protected void Page_Load(object sender, EventArgs e)
        {            
            string sAccessToken = string.Empty;
            string sIntanceURL = string.Empty;
            string sConsumerKey = string.Empty;
            string sAPIUrl = string.Empty;
            string sContentType = string.Empty;
            string sFileTitle = string.Empty;

            sConsumerKey = Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_QS_CONSUMER_KEY].ToString());
            sIntanceURL = Utility.CustomEncoder(Request.QueryString[SFConstants.CONST_QS_INSTANCE_URL].ToString());
            sAPIUrl = Utility.CustomEncoder(Request.QueryString["APIURL"].ToString());
            sContentType = Utility.CustomEncoder(Request.QueryString["MIMETYPE"].ToString());
            sFileTitle = Utility.CustomEncoder(Request.QueryString["FILETITLE"].ToString());

            sAccessToken = Utility.GetPersistedAccessToken(sConsumerKey);
            m_oChatterRESTAPI.AccessToken = sAccessToken;

            string m_sAPIUrl = sIntanceURL + sAPIUrl;
            HttpWebRequest oWebRequest = null;
            HttpWebResponse response = null;

            oWebRequest = System.Net.WebRequest.Create(m_sAPIUrl) as HttpWebRequest;
            oWebRequest.Headers.Add("Authorization", "OAuth " + m_oChatterRESTAPI.AccessToken);
            oWebRequest.ContentType = "application/x-www-form-urlencoded";
            oWebRequest.Method = "GET";
            oWebRequest.ServicePoint.Expect100Continue = false;
            oWebRequest.Timeout = 10000;
            oWebRequest.AllowWriteStreamBuffering = false;
            response = (HttpWebResponse)oWebRequest.GetResponse();

            Stream s = response.GetResponseStream();
            byte[] data;

            using (Stream fileStream = s)
            {
                using (BinaryReader binaryReader = new BinaryReader(fileStream))
                {
                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        byte[] buffer = new byte[256];
                        int count;
                        int totalBytes = 0;
                        while ((count = binaryReader.Read(buffer, 0, 256)) > 0)
                        {
                            memoryStream.Write(buffer, 0, count);
                            totalBytes += count;
                        }
                        memoryStream.Position = 0;
                        data = new byte[totalBytes];
                        memoryStream.Read(data, 0, totalBytes);
                    }
                }
            }

            Response.ContentType = sContentType;
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + sFileTitle);            
            Response.BinaryWrite(data);            
            Response.End();            

        }
    }
}
