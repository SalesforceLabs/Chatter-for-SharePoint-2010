﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using System.Web;
using System.Collections.Generic;
using System.Text;
using SalesForce.ChatterMiddleTier;
using System.Web.Caching;
using System.Linq;

namespace SalesForce.ChatterWP2010
{
    public partial class GetSMUsers : IHttpHandler
    {
        
        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        List<OrgUserDetail> oUserList;
        public bool IsReusable
        {
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string sIntanceURL = string.Empty;
            string sAccessToken = string.Empty;
            string sPrefixText = string.Empty;
            StringBuilder sbResult = new StringBuilder(100);
            try
            {
                sPrefixText = context.Request.QueryString["q"];
                sPrefixText = sPrefixText.Substring(sPrefixText.LastIndexOf(",") + 1);

                sIntanceURL = context.Request.QueryString[SFConstants.CONST_QS_INSTANCE_URL].ToString();
                sAccessToken = Utility.GetPersistedAccessToken(context.Request.QueryString[SFConstants.CONST_QS_CALLBACK_URL].ToString());
              

                m_oChatterRESTAPI.ChatterAPIEndpoint = sIntanceURL;
                m_oChatterRESTAPI.AccessToken = sAccessToken;

                oUserList = GetFilteredUsers(sPrefixText);

                
                if (oUserList.Count > 0)
                {
                    foreach (OrgUserDetail ud in oUserList)
                    {
                        sbResult.Append(string.Format("{0}\\*\\{1}\\*\\{2}{3}",
                                   ud.Name, string.Format(SFConstants.CONST_sOAuth_Token, ud.Photo.SmallPhotoURL, m_oChatterRESTAPI.AccessToken), ud.ID, Environment.NewLine));
                    }
                }
                else
                {
                    sbResult.Append(string.Format(SFConstants.CONST_SM_NORESULT_FORMAT,Utility.CustomEncoder(sPrefixText)));
                }
                

               
                char cbar = '|';
                sbResult.Replace(cbar.ToString(), String.Format("&#{0};", (int)cbar));
                context.Response.Write(sbResult);
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
            }
        }

        /// <summary>
        /// Get Filtered users based on Query String
        /// </summary>        
        private List<OrgUserDetail> GetFilteredUsers(string sUserName)
        {
            try
            {
                Utility.LoadConfigDataFromWebConfig(m_oChatterRESTAPI);
                oUserList = new List<OrgUserDetail>();
                oUserList = m_oChatterRESTAPI.GetOrgUsers(sUserName).Users.ToList();
                return oUserList;
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
                return null;
            }
        }
    }
}
