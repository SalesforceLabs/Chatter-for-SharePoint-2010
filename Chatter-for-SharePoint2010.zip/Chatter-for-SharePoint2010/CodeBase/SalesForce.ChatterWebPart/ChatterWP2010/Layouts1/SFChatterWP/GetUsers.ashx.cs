﻿using System;
using Microsoft.SharePoint;
using System.Web;
using System.Collections.Generic;
using SalesForce.ChatterMiddleTier;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;

namespace SalesForce.ChatterWP2010
{
    public partial class GetUsers : IHttpHandler
    {
        private const string CONST_TWO_PARAMETER_FORMAT = "{0}\\*\\{1}";
        private const string CONST_MESSAGE = "msg";
        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        int iCursorPosition = -1;

        private enum enSearchType
        {
            Mention = 0
        } ;

        public bool IsReusable
        {
            get { return true; }
        }
        
        /// <summary>
        /// Event to handle process request...
        /// </summary>
        public void ProcessRequest(HttpContext context)
        {
            string sFeedText = string.Empty;
            string sSearchText = string.Empty;
            string sIntanceURL = string.Empty;
            string sAccessToken = string.Empty;
            int iBrower = 0;

            StringBuilder sbResult = new StringBuilder(200);
            try
            {
                // Get text input value
                sFeedText = context.Request.QueryString["q"];
                string[] arrCurNBrowser = context.Request.QueryString["CP"].ToString().Split(',');

                iCursorPosition = Convert.ToInt32(arrCurNBrowser[0]);
                iBrower = Convert.ToInt32(arrCurNBrowser[1]);

                // Moziall
                if (iBrower == 0)
                {
                    // Replace new line character with space
                    sFeedText = Regex.Replace(sFeedText, "[\n\r\t]", " ");
                }
                else
                {
                    sFeedText = Regex.Replace(sFeedText, "[\n\r\t]", "  ");
                }

                sFeedText = sFeedText.Substring(0, iCursorPosition);
                

                // if string doesn't contain @ and # then return 
                if (!sFeedText.Contains('@'))
                {
                    return;
                }

                sIntanceURL = context.Request.QueryString[SFConstants.CONST_QS_INSTANCE_URL].ToString();
                sAccessToken = Utility.GetPersistedAccessToken(context.Request.QueryString[SFConstants.CONST_QS_CALLBACK_URL].ToString());

                // if string contains @
                if (sFeedText.Contains('@') && sFeedText.LastIndexOf('@') > sFeedText.LastIndexOf('#'))
                {
                    // if last character is @ then display help message
                    if (sFeedText.Length == sFeedText.LastIndexOf('@') + 1)
                    {
                        sbResult.Append(string.Format(CONST_TWO_PARAMETER_FORMAT, SFConstants.CONST_MENTION_HELP, CONST_MESSAGE));
                        context.Response.Write(sbResult);
                        return;
                    }

                    // If Maching records exists then display otherwise display No Macth message 
                    sbResult = GetSearchResult(sFeedText, sIntanceURL, sAccessToken, enSearchType.Mention);
                 
                    char cbar = '|';
                    sbResult.Replace(cbar.ToString(), String.Format("&#{0};", (int)cbar));
                    context.Response.Write(sbResult);
                    return;
                }
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
            }
        }

        #region Private Methods

        /// <summary>
        /// Method is used to get Search Result on the basis of search type Mention / Hastag
        /// </summary>
        private StringBuilder GetSearchResult(string sFeedText, string sIntanceURL, string sAccessToken, enSearchType eSearchType)
        {
            string sSearchText = string.Empty;
            try
            {
                Utility.LoadConfigDataFromWebConfig(m_oChatterRESTAPI);
                m_oChatterRESTAPI.ChatterAPIEndpoint = sIntanceURL;
                m_oChatterRESTAPI.AccessToken = sAccessToken;

                switch (eSearchType)
                {
                    case enSearchType.Mention:
                        #region Mention
                        //get search text 
                        sSearchText = sFeedText.Substring(sFeedText.LastIndexOf('@') + 1, sFeedText.Length - sFeedText.LastIndexOf('@') - 1);

                        // if search text contains space then return
                        if (sSearchText.Contains(" "))
                        {
                            return new StringBuilder(SFConstants.CONST_NO_RESULT);
                        }

                        // Search Mention
                        return GetMention(sSearchText);
                        #endregion
                }
                return null;
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
                return null;
            }
        }
        
        /// <summary>
        /// Get Filtered users based on Query String
        /// </summary>        
        private StringBuilder GetMention(string sMentionText)
        {
            List<OrgUserDetail> oUerList = new List<OrgUserDetail>();
            StringBuilder sbResult = new StringBuilder(1000);
            try
            {
                oUerList = m_oChatterRESTAPI.GetOrgUsers(sMentionText).Users.ToList();

                if (oUerList.Count == 0)
                {
                    sbResult.Append(string.Format(CONST_TWO_PARAMETER_FORMAT, SFConstants.CONST_MENTION_NOMATCH, CONST_MESSAGE));
                    return sbResult;
                }

                foreach (OrgUserDetail oUser in oUerList)
                {
                    sbResult.Append(string.Format("{0}\\*\\{1}\\*\\{2}\\*\\{3}\\*\\{4}\\*\\{5}",
                               oUser.Name, oUser.Photo.SmallPhotoURL, "user", oUser.ID, iCursorPosition, Environment.NewLine));
                }

                return sbResult;
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
                return null;
            }
        }
        #endregion
    }
}
