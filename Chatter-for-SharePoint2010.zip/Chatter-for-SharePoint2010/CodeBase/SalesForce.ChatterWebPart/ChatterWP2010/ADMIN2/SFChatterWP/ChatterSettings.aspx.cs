﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using SalesForce.ChatterMiddleTier;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml;
using System.Text;
using System.Xml.Linq;
using Microsoft.SharePoint.Utilities;

namespace SalesForce.ChatterWP2010
{
    public partial class ChatterSettings : LayoutsPageBase
    {
        #region Private Variables

        SPWebApplication webApplication;
        SFChatterBAL m_oSFChatterBAL = new SFChatterBAL();
        private string strConsumerKey = string.Empty;
        private string strConsumerSecret = string.Empty;
        private string strCallBackURL = string.Empty;
        private string strABIBaseURL = string.Empty;
        private string strAuthorizationURL = string.Empty;
        private string strAccessTokenURL = string.Empty;
        private string strEncryptionDecryptionKey = string.Empty;
        private string strAutoRefreshTimer = string.Empty;
        private string strAutoCompleteCount = string.Empty;
        private string strAllowFileUpload = string.Empty;

        #endregion

        #region Public Properties
        public string SecurityMessage
        {
            get
            {
                return SFConstants.CONST_MSG_NOT_SHOWN_SECURITY;
            }
        }
        #endregion

        #region Events

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Intialization();
                    GetAllConfigurations();
                    SetControlValues();
                }
                lblMessage.Visible = false;
            }
            catch (Exception ex)
            { 
                lblMessage.Visible = true;
                lblMessage.Text = m_oSFChatterBAL.HandleError(SFConstants.CONST_EVENT_PAGELOAD, ex.Message, SFConstants.CONST_ADMIN_ERR_MSG);
            }
        }
        
        /// <summary>
        /// Event Handler for change in the dropdown selection. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlWebApplication_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                webApplication = SPWebApplication.Lookup(new Uri(ddlWebApplication.SelectedValue));
                GetAllConfigurations();
                SetControlValues();
            }
            catch (Exception ex)
            { 
                lblMessage.Visible = true;
                lblMessage.Text = m_oSFChatterBAL.HandleError("ddlWebApplication_OnSelectedIndexChanged", ex.Message, SFConstants.CONST_ADMIN_ERR_MSG);
            }
        }

        /// <summary>
        /// Event Handler to submit the Updated Values.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                webApplication = SPWebApplication.Lookup(new Uri(ddlWebApplication.SelectedValue));
                GetAllConfigurations();
                GetControlValues();
                UpdateAllConfigurations();
                lblMessage.Visible = true;
                lblMessage.Text = "The configuration for web application "+ ddlWebApplication.SelectedValue +" are stored successfully.";
            }
            catch (Exception ex)
            {  
                lblMessage.Visible = true;
                lblMessage.Text = m_oSFChatterBAL.HandleError("btnOk_Click", ex.Message, SFConstants.CONST_ADMIN_ERR_MSG);
            }
        }


        #endregion

        #region Private Functions

        /// <summary>
        /// Intializes the page with WebApplications
        /// </summary>
        private void Intialization()
        {
            SPFarm frmLocal = SPFarm.Local;
            //Get Web Applications using soultion Name. Need to check if this is right approach  
            SPSolution solution = frmLocal.Solutions[new Guid(SFConstants.CONST_2010_Solution_Id)];
            if (solution == null || solution.DeployedWebApplications == null)
            {
                lblMessage.Visible = true;
                lblMessage.Text = "No web application found on which the Chatter Connector solution is deployed.";
                return;
            }
            BtnOk.Enabled = true;
            BtnOkTop.Enabled = true;
            ddlWebApplication.Items.Clear();
            foreach (SPWebApplication webapplication in solution.DeployedWebApplications)
            {
                ddlWebApplication.Items.Add(webapplication.GetResponseUri(SPUrlZone.Default).AbsoluteUri);
            }
            webApplication = SPWebApplication.Lookup(new Uri(ddlWebApplication.SelectedValue));
        }

        /// <summary>
        /// This functions sets the default values of the configurations.
        /// </summary>
        private void SetDefaultValues()
        {
            try
            {
                this.strCallBackURL = ddlWebApplication.SelectedValue + SFConstants.CONST_CHATTER_CALLBACK_URL;
                this.strABIBaseURL = SFConstants.CONST_CONFIG_DEFAULT_ABI_BASE;
                this.strAuthorizationURL = SFConstants.CONST_CONFIG_DEFAULT_AUTHORIZATION_URL;
                this.strAccessTokenURL = SFConstants.CONST_CONFIG_DEFAULT_ACCESS_TOKEN_URL;
                this.strEncryptionDecryptionKey = SFConstants.CONST_CONFIG_DEFAULT_ENCRYPT_DECRYPT_KEY;
                this.strAutoRefreshTimer = SFConstants.CONST_CONFIG_DEFAULT_AUTO_REFRESH_TIMER;
                this.strAutoCompleteCount = SFConstants.CONST_CONFIG_DEFAULT_AUTO_COMPLETE_COUNT;
                this.strAllowFileUpload = SFConstants.CONST_CONFIG_DEFAULT_ALLOW_FILE_UPLOAD;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This function will get all the control values. Any modification before using the vales can be done here.
        /// </summary>
        private void GetControlValues()
        {
            try
            {
                if (!string.Equals(this.txtEncryptionKey.Text, SFConstants.CONST_MSG_NOT_SHOWN_SECURITY))
                {
                    this.strEncryptionDecryptionKey = txtEncryptionKey.Text;
                }
                this.strCallBackURL = txtCallBackURL.Text;
                if (!string.Equals(this.txtConsumerKey.Text, SFConstants.CONST_MSG_NOT_SHOWN_SECURITY))
                {
                    this.strConsumerKey = CreateListUtility.EncryptKey(txtConsumerKey.Text, this.strEncryptionDecryptionKey);
                }
                if (!string.Equals(this.txtConsumerSecret.Text, SFConstants.CONST_MSG_NOT_SHOWN_SECURITY))
                {
                    this.strConsumerSecret = CreateListUtility.EncryptKey(txtConsumerSecret.Text, this.strEncryptionDecryptionKey);
                }
                this.strABIBaseURL = txtAPIBase.Text;
                this.strAuthorizationURL = txtAuthorizationURL.Text;
                this.strAccessTokenURL = txtAccessTokenURL.Text;
                this.strAutoRefreshTimer = txtAutoRefresh.Text;
                this.strAutoCompleteCount = txtAutoCompleteUserCount.Text;
                this.strAllowFileUpload = rdUploadOn.Checked.ToString();
            }
            catch
            {
                throw;
            }
        }
        
        /// <summary>
        /// This function will set all the control values. Any modification before seting the vales can be done here.
        /// </summary>
        private void SetControlValues()
        {
            try
            {

                if (!string.IsNullOrEmpty(this.strEncryptionDecryptionKey))
                {
                    this.txtEncryptionKey.Text = SFConstants.CONST_MSG_NOT_SHOWN_SECURITY;
                    this.txtEncryptionKey.ForeColor = System.Drawing.Color.Gray;
                }
                else
                {
                    this.txtEncryptionKey.Text = string.Empty;
                    this.txtEncryptionKey.ForeColor = System.Drawing.Color.Black;
                }
                if (!string.IsNullOrEmpty(this.strConsumerKey))
                {
                    this.txtConsumerKey.Text = SFConstants.CONST_MSG_NOT_SHOWN_SECURITY;
                    this.txtConsumerKey.ForeColor = System.Drawing.Color.Gray;
                }
                else
                {
                    this.txtConsumerKey.Text = string.Empty;
                    this.txtConsumerKey.ForeColor = System.Drawing.Color.Black;
                }
                if (!string.IsNullOrEmpty(this.strConsumerSecret))
                {
                    this.txtConsumerSecret.Text = SFConstants.CONST_MSG_NOT_SHOWN_SECURITY;
                    this.txtConsumerSecret.ForeColor = System.Drawing.Color.Gray;
                }
                else
                {
                    this.txtConsumerSecret.Text = string.Empty;
                    this.txtConsumerSecret.ForeColor = System.Drawing.Color.Black;
                }
                txtCallBackURL.Text = this.strCallBackURL;
                txtAPIBase.Text = this.strABIBaseURL;
                txtAuthorizationURL.Text = this.strAuthorizationURL;
                txtAccessTokenURL.Text = this.strAccessTokenURL;
                txtAutoRefresh.Text = this.strAutoRefreshTimer;
                txtAutoCompleteUserCount.Text = this.strAutoCompleteCount;
                rdUploadOn.Checked = bool.Parse(this.strAllowFileUpload);
            }
            catch { throw; }
        }

        /// <summary>
        /// The function will get all the configuration details from web.config. 
        /// </summary>
        private void GetAllConfigurations()
        {
            SetDefaultValues();
            try
            {
                StringBuilder sbXMLConfig = new StringBuilder();
                sbXMLConfig.Append("<SFChatter>");
                foreach (SPWebConfigModification modification in webApplication.WebConfigModifications)
                {
                    if (modification.Owner.Equals(SFConstants.CONST_WEB_CONFIG_MODIFICATION_OWNER))
                    {
                        sbXMLConfig.Append(modification.Value);
                    }
                }
                sbXMLConfig.Append("</SFChatter>");
                var doc = XDocument.Parse(sbXMLConfig.ToString());
                foreach (var configuration in doc.Root.Elements(SFConstants.CONST_CONFIG_ADD))
                {
                    switch(configuration.Attribute(SFConstants.CONST_CONFIG_KEY).Value) 
                    {
                        case SFConstants.CONST_CONFIG_KEY_CONSUMER_KEY:
                            this.strConsumerKey = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_CONSUMER_SECRET:
                            this.strConsumerSecret = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_ABI_BASE:
                            this.strABIBaseURL = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_ACCESS_TOKEN_URL:
                            this.strAccessTokenURL = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_AUTHORIZATION_URL:
                            this.strAuthorizationURL = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_ENCRYPT_DECRYPT_KEY:
                            this.strEncryptionDecryptionKey = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_AUTO_COMPLETE_COUNT:
                            this.strAutoCompleteCount = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_AUTO_REFRESH_TIMER:
                            this.strAutoRefreshTimer = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_ALLOW_FILE_UPLOAD:
                            this.strAllowFileUpload = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                        case SFConstants.CONST_CONFIG_KEY_CALLBACK_URL:
                            this.strCallBackURL = configuration.Attribute(SFConstants.CONST_CONFIG_VALUE).Value;
                            break;
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// The function stores all the configuration details in web.config. 
        /// </summary>
        private void UpdateAllConfigurations()
        {
            try
            {
                AddAppSettingsSectionWebConfig();
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_CONSUMER_KEY, this.strConsumerKey);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_CONSUMER_SECRET, this.strConsumerSecret);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_ABI_BASE, this.strABIBaseURL);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_ACCESS_TOKEN_URL, this.strAccessTokenURL);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_AUTHORIZATION_URL, this.strAuthorizationURL);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_ENCRYPT_DECRYPT_KEY, this.strEncryptionDecryptionKey);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_AUTO_COMPLETE_COUNT, this.strAutoCompleteCount);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_AUTO_REFRESH_TIMER, this.strAutoRefreshTimer);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_ALLOW_FILE_UPLOAD, this.strAllowFileUpload);
                SubmitAppSettingsWebConfig(SFConstants.CONST_CONFIG_KEY_CALLBACK_URL, this.strCallBackURL);
                webApplication.Update();
                webApplication.Farm.Services.GetValue<SPWebService>().ApplyWebConfigModifications();
            }
            catch 
            {
                throw;
            }
        }

        /// <summary>
        /// This function adds the appSeetings section in webconfig is not present.
        /// </summary>
        private void AddAppSettingsSectionWebConfig()
        {
            SPWebConfigModification modification = new SPWebConfigModification();
            modification.Name = "appSettings";
            modification.Path = "configuration";
            modification.Sequence = 0;
            modification.Owner = "appSettings";
            modification.Type = SPWebConfigModification.SPWebConfigModificationType.EnsureSection;
            modification.Value = "<appSettings></appSettings>";
            try
            {
                if (!webApplication.WebConfigModifications.Contains(modification))
                {
                    webApplication.WebConfigModifications.Add(modification);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// This function wrapes two function which remove and add appconfig entries. 
        /// </summary>
        /// <param name="sKey">Key</param>
        /// <param name="sValue">Vale</param>
        private void SubmitAppSettingsWebConfig(string sKey, string sValue)
        {
            RemoveAppSettingsWebConfig(sKey, SFConstants.CONST_WEB_CONFIG_MODIFICATION_OWNER);
            AddAppSettingsWebConfig(sKey, sValue);
        }

        /// <summary>
        /// The funcation adds key value pair to AppSetting in Web Config
        /// </summary>
        /// <param name="sKey">Key</param>
        /// <param name="sValue">Value</param>
        private void AddAppSettingsWebConfig(string sKey, string sValue)
        {
            SPWebConfigModification modification = new SPWebConfigModification();
            modification.Name =string.Format(SFConstants.CONST_APP_SETTINGS_NAME_FORMAT, sKey);
            modification.Path = SFConstants.CONST_APP_SETTINGS_XPATH;
            modification.Value = string.Format(SFConstants.CONST_APP_SETTINGS_VALUE_FORMAT, sKey, sValue);;
            modification.Sequence = 0;
            modification.Type = SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode;;
            modification.Owner = SFConstants.CONST_WEB_CONFIG_MODIFICATION_OWNER;
            try
            {
                webApplication.WebConfigModifications.Add(modification);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// The function removes all the moficiations of a particular key and owner.
        /// The Key used to map to the Name. 
        /// </summary>
        /// <param name="sKey"></param>
        private void RemoveAppSettingsWebConfig(string sKey,string sOwner)
        {
            try
            {
                List<SPWebConfigModification> removeModifications = new List<SPWebConfigModification>();
                foreach (SPWebConfigModification modification in webApplication.WebConfigModifications)
                {
                    if (modification.Owner.Equals(sOwner)
                        && modification.Name.Equals(string.Format(SFConstants.CONST_APP_SETTINGS_NAME_FORMAT, sKey)))
                    {
                        removeModifications.Add(modification);
                    }
                }
                foreach (SPWebConfigModification modification in removeModifications)
                {
                    webApplication.WebConfigModifications.Remove(modification);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion  
    }
}
