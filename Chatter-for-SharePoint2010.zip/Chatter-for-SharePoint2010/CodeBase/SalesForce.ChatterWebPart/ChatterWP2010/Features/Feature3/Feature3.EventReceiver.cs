using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;

namespace SalesForce.ChatterWP2010
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("0b10a78f-3708-4e81-8ac9-f811c32d7bfa")]
    public class Feature3EventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPSite oCurrentSite = properties.Feature.Parent as SPSite;
                SPWeb oCurrentWeb = oCurrentSite.RootWeb;
                CreateListUtility.CreateConsumerKeyList(oCurrentWeb);
                CreateListUtility.CreateRefreshTokenList(oCurrentWeb);
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SalesForce.ChatterMiddleTier.SFConstants.CONST_CHATTER, ex.Message);
            }
        }
    }
}
