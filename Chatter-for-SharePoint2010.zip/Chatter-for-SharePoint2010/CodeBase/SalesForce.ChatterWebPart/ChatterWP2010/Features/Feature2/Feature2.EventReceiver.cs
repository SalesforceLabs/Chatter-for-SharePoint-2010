using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using SalesForce.ChatterMiddleTier;

namespace SalesForce.ChatterWP2010
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("6297dc9a-19e7-4826-a195-0d65d2917d8e")]
    public class Feature2EventReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPWeb oCurrentWeb = properties.Feature.Parent as SPWeb;
                CreateListUtility.CreateConsumerKeyList(oCurrentWeb);
                CreateListUtility.CreateRefreshTokenList(oCurrentWeb);
            }
            catch (Exception ex)
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, ex.Message);
            }
        }
    }
}
