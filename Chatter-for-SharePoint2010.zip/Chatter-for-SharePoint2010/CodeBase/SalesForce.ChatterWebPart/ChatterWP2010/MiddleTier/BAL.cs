﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using SalesForce.ChatterMiddleTier;
using System.Text.RegularExpressions;
using Microsoft.SharePoint;
using System.Net;
using System.IO;

namespace SalesForce.ChatterWP2010
{
    public class SFChatterBAL
    {
        #region Variables
        ChatterRESTAPI m_oChatterRESTAPI = new ChatterRESTAPI();
        #endregion Variables

        #region Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public string ReplaceHTML(string html)
        {
            html = Regex.Replace(html, @"^\s+<", " <", RegexOptions.Multiline);
            html = Regex.Replace(html, @">\s+<", "> <", RegexOptions.Multiline);
            return html;
        }

        // Get called from Javascript
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sInputFeed"></param>
        /// <returns></returns>
        public string GetFeedTextAsHtml(string sInputFeed)
        {
            try
            {
                    return sInputFeed.Replace("\n", "<br>");
            }
            catch (Exception ex)
            {
                HandleError(ex.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="stackTrace"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public string HandleError(string sEventName, string stackTrace, string key)
        {
            string sResourceKey = "$Resources: {0}";
            string sErrFormat = "{0} : {1}";
            string sError = string.Empty;
            try
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, string.Format(sErrFormat, sEventName, stackTrace));
                sError = SPUtility.GetLocalizedString(string.Format(sResourceKey, key), "ErrorResource\\ErrorResource", (uint)1033);
                return sError;
            }
            catch (Exception) { return string.Empty; }            
        }
        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="stackTrace"></param>
        public string HandleError(string stackTrace)
        {
            try
            {
                LoggingService.LogMessage(SFConstants.CONST_CHATTER, stackTrace);
            }
            catch (Exception) { }
            return string.Empty;
        }

        /// <summary>
        /// This function is used to fetch the like ID of the current Feed.
        /// It is then used in UnlikeItem function.
        /// </summary>
        public string GetFeedLikeID(List<Like> oLikes, string sMyId)
        {
            try
            {
                string m_sMylikeID = string.Empty;
                var varlikeID = oLikes.Where(l => l.User.ID == sMyId);
                foreach (var item in varlikeID)
                {
                    m_sMylikeID = item.ID;
                    break;
                }

                return m_sMylikeID;
            }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Get Like text of Feed
        /// </summary>
        /// <param name="iTotalCount"></param>
        /// <param name="isFound"></param>
        /// <param name="lstAllLikes"></param>
        /// <param name="iMyLikeIndex"></param>
        /// <param name="bIsUnlikeClicked"></param>      
        /// <param name="sFeedID">This value is used to pass to javascript function OpenDialogForUserList(). This is done while setting the 'Others' link.</param>
        /// <param name="sMyID">This value is used to pass to javascript function OpenDialogForUserList(). This is done while setting the 'Others' link.</param>
        /// <param name="sConsumerKey">This value is used to pass to javascript function OpenDialogForUserList(). This is done while setting the 'Others' link.</param>
        /// <param name="sConsumerSecret">This value is used to pass to javascript function OpenDialogForUserList(). This is done while setting the 'Others' link.</param>
        /// <param name="sOthersCount">This value is used to pass to javascript function OpenDialogForUserList(). This is done while setting the 'Others' link.</param>
        /// <returns></returns>
        public string GetFeedLikesText(int iTotalCount, bool isFound, List<Like> lstAllLikes, string sMyLikeID,
                                        string sFeedID, string sMyID, string sConsumerKey, string sConsumerSecret, string sOthersCount /*These parameters are used for setting text and link for 'others' */
                                        )
        {
            string sLikeText = string.Empty;
            string sLikeTextValue = "like this";
            string sMyLikeIndex = string.Empty; /*This variable is used to pass the MyIndex value to the pop up page.It will be set only if 
                                                 * LoggedIn user is found in the Likes list. Here iMyLikeIndex cannot be used because, even if 
                                                 * LoggedIn user is not found in the likes list, it will contain value 0, which is an index itself. */
            string sFirstUser = string.Empty;
            string sSecondUser = string.Empty;
            string sThirdUser = string.Empty;
            string m_sMylikeID = string.Empty;

            if (iTotalCount == 0)
                return string.Empty;

            #region Set First, Second, Third User Names
            // If You is found in the Likes list, then set the First,Second, and Third user names accordingly
            if (isFound)
            {
                // First User Name will always be 'You' (if found)
                sFirstUser = SFConstants.CONST_YOU;

                switch (iTotalCount)
                {
                    case 0:
                    case 1:
                        break;

                    // For Default(more than 3 users) and Case 2, only 2 users will be shown, hence same case can be used.
                    default:
                    case 2:
                        // Set Second User
                        if (lstAllLikes[iTotalCount - 1].ID == sMyLikeID)
                            sSecondUser = lstAllLikes[iTotalCount - 2].User.Name;
                        else
                            sSecondUser = lstAllLikes[iTotalCount - 1].User.Name;
                        break;

                    case 3:
                        // Set Second and Third Users
                        if (lstAllLikes[iTotalCount - 1].ID == sMyLikeID)
                        {
                            sSecondUser = lstAllLikes[iTotalCount - 2].User.Name;
                            sThirdUser = lstAllLikes[iTotalCount - 3].User.Name;
                        }
                        else if (lstAllLikes[iTotalCount - 2].ID == sMyLikeID)
                        {
                            sSecondUser = lstAllLikes[iTotalCount - 1].User.Name;
                            sThirdUser = lstAllLikes[iTotalCount - 3].User.Name;
                        }
                        else
                        {
                            sSecondUser = lstAllLikes[iTotalCount - 1].User.Name;
                            sThirdUser = lstAllLikes[iTotalCount - 2].User.Name;
                        }
                        break;
                }
            }
            else // Set the first three users 
            {
                sFirstUser = lstAllLikes[iTotalCount - 1].User.Name;

                if (iTotalCount == 1)
                    sLikeTextValue = "likes this";  //Set the text to 'likes this' only if one user other than loggedin user likes the feed.

                if (iTotalCount > 1)
                    sSecondUser = lstAllLikes[iTotalCount - 2].User.Name;

                if (iTotalCount > 2)
                    sThirdUser = lstAllLikes[iTotalCount - 3].User.Name;
            }
            #endregion

            #region Set Likes Text
            // Set the Likes label to display the user names
            switch (iTotalCount)
            {
                case 0:
                    break;
                case 1:
                    sLikeText = string.Format(SFConstants.CONST_LikeOneUserFomrat, string.Format(SFConstants.CONST_UNameFormat, sFirstUser), sLikeTextValue);
                    break;
                case 2:
                    sLikeText = string.Format(SFConstants.CONST_LikeTwoUserFormat,
                                                string.Format(SFConstants.CONST_UNameFormat, sFirstUser),
                                                string.Format(SFConstants.CONST_UNameFormat, sSecondUser),
                                                sLikeTextValue);
                    break;
                case 3:
                    sLikeText = string.Format(SFConstants.CONST_LikeThreeUserFormat,
                                              string.Format(SFConstants.CONST_UNameFormat, sFirstUser),
                                              string.Format(SFConstants.CONST_UNameFormat, sSecondUser),
                                              string.Format(SFConstants.CONST_UNameFormat, sThirdUser),
                                              sLikeTextValue);
                    break;
                default:
                    sLikeText = string.Format(SFConstants.CONST_LikeMoreUserFormat,
                                              string.Format(SFConstants.CONST_UNameFormat, sFirstUser),
                                              string.Format(SFConstants.CONST_UNameFormat, sSecondUser),
                                              string.Format(SFConstants.CONST_OthersFormat, sFeedID, sMyID, sConsumerKey, sConsumerSecret, sOthersCount), /*Others link*/
                                              sLikeTextValue);
                    break;
            }
            #endregion

            return sLikeText;
        }

        /// <summary>
        /// Get and Log Exception details
        /// </summary>
        /// <param name="webex"></param>
        /// <returns></returns>
        public string HandleException(WebException webex)
        {
            string sError = webex.Message;
            try
            {
                if (webex.Response != null)
                {
                    string sWebException = new StreamReader(webex.Response.GetResponseStream()).ReadToEnd();
                    sWebException = sWebException.TrimStart('[').TrimEnd(']');
                    ErrorMessage oErrorMessage = SalesForce.ChatterMiddleTier.Utility.GetObjectFromJSON<ErrorMessage>(sWebException);
                    sError = string.IsNullOrEmpty(oErrorMessage.Message) ? oErrorMessage.Error_Description : oErrorMessage.Message;
                }
                HandleError(sError);
                return sError;
            }
            catch (WebException) { return string.Empty; }
            catch (Exception) { return string.Empty; }
            finally
            {
                HandleError(sError);
            }
        }

        /// <summary>
        /// Upload File from Computer
        /// </summary>        
        public FeedItem UploadFile(Stream oStream, string fileName, string txtFileName, string description, string sFilePost, string group, ChatterRESTAPI oChatterRESTAPI, string sMentionList)
        {
            try
            {
                if (oStream == null)
                    return null;

                byte[] byteFileData = new byte[oStream.Length];
                oStream.Read(byteFileData, 0, byteFileData.Length);
                oStream.Close();

                string[] sFName = fileName.Split('.');
                txtFileName = txtFileName + "." + sFName[sFName.Length - 1];

                return oChatterRESTAPI.UploadFile(byteFileData, txtFileName, description, sFilePost, group, sMentionList);
                oStream.Dispose();
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }
        #endregion Methods
    }
}
