using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.IO;
using System.Collections.Specialized;
using SalesForce.ChatterMiddleTier;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;

namespace SalesForce.ChatterMiddleTier
{
    public enum enMethod { GET, POST, DELETE };

    public class ChatterRESTAPI
    {
        #region Chatter REST Api Constant

        private const string CONST_API_ME = "/users/me";
        private const string CONST_API_MY_FOLLOWINGS = "/users/me/following";
        private const string CONST_API_MY_NEWS_FEEDS = "/feeds/news/me/feed-items";
        private const string CONST_API_MY_GROUPS = "/users/me/groups";
        private const string CONST_API_FEEDS_TO_ME = "/feeds/to/me/feed-items";
        private const string CONST_API_MY_PROFILE_FEEDS = "/feeds/user-profile/me/feed-items";
        private const string CONST_API_MY_STATUS = "/users/me/status";
        private const string CONST_API_RECORD = "/feeds/record/me/feed-items";
        private const string CONST_API_MY_FOLLOWERS = "/users/me/followers";
        private const string CONST_API_UPDATE_MY_STATUS = "/feeds/news/me/feed-items?text=";
        private const string CONST_API_POST_UPDATE_MY_STATUS = "/feeds/news/me/feed-items";
        private const string CONST_API_FOLLOW_RECORD = "/users/me/following?subjectId=";
        private const string CONST_API_UNFOLLOW_RECORD = "/subscriptions/";
        private const string CONST_API_FILE_UPLOAD = "/feeds/news/me/feed-items";
        private const string CONST_API_RESPONSE_TYPE = "code";
        private const string CONST_API_DISPLAY = "popup";
        private const string CONST_API_CHATTER_GROUPS = "/groups/";
        private const string CONST_API_CHATTER_FEEDS = "feed-items";
        private const string CONST_API_TOPICS = "/topics/trending";
        private string CONST_API_BASIC_FORMAT = "{0}{1}{2}";
        private string CONST_API_BASIC_FORMAT_ORG_USER_LIST = "{0}{1}{2}?q={3}&pageSize={4}";
        private string m_sUploadFileToMyWall = "{0}{1}{2}";
        private string m_sGroupInfoFormat = "{0}{1}{2}{3}";
        private const string CONST_API_FILTER_FEEDS = "/feeds";
        private string CONST_API_USERS = "/users";
        private string CONST_MENTION = "mention";
        private string CONST_TEXT = "text";
        private string m_sFolloweUserFormat = "{0}{1}{2}{3}";
        private string m_sUnFollowFormat = "{0}{1}";
        private string m_sPostPrivateMessage = "{0}{1}/users/me/messages";
        private string CONST_API_USERBATCH = "{0}{1}/users/batch/{2}";

        #endregion

        #region Chatter REST API String Format

        private string m_sUpdateStatusAtGroupWall = "{0}{1}/feeds/record/{2}/feed-items?text={3}";
        private string m_sPostToGroupWallFormat = "{0}{1}/feeds/record/{2}/feed-items";
        private string m_sLikesFroamt = "{0}{1}/{2}/{3}/likes";
        private string m_sFeedItemsUpdateFormat = "{0}{1}/{2}/{3}";
        private string m_sCommentDeleteFormat = "{0}{1}/comments/{2}";
        private string m_sUnLikeFormat = "{0}{1}/likes/{2}";
        private string m_sCommentPostFormat = "{0}{1}/{2}/{3}/comments";
        private string m_sCommentFormat = "{0}{1}/{2}/{3}/comments?text={4}";
        private string m_sPostToMyWallFormat = "{0}{1}{2}{3}";
        private string m_sPostFeedFormat = "{0}{1}{2}";
        private string m_sFeedCommentsUpdateFormat = "{0}{1}/{2}/{3}/comments";
        private string m_sAccessTknFrmRefTknFormat = "{0}?grant_type=refresh_token&client_id={1}&client_secret={2}&refresh_token={3}";
        private string m_sAccessTknFrmAuthTknFormat = "{0}?grant_type=authorization_code&code={1}&client_id={2}&client_secret={3}&redirect_uri={4}";
        private string m_sAuthTknFormat = "{0}?response_type=code&client_id={1}&redirect_uri={2}&display={3}&state={4}";
        private string m_sGroupFeedsFormat = "{0}{1}/feeds/record/{2}/feed-items?pageSize=20";
        private string m_sLinkPostFormat = "{0}{1}{2}?url={3}&urlName={4}&text={5}";
        private string m_sGroupLinkPostFormat = "{0}{1}/feeds/record/{2}/feed-items?url={3}&urlName={4}&text={5}";
        private string m_sGroupFeedsPageFormat = "{0}{1}";
        private string m_sUploadFileToGroupWallFormat = "{0}{1}/feeds/record/{2}/feed-items";
        private string m_sSearchGroupFormat = "{0}{1}/groups?q={2}";
        private string m_sThreeParametersFormat = "{0}{1}{2}";
        private string m_sTwoParametersFormat = "{0}{1}";
        #endregion

        #region Chatter Member Variables

        private string m_sUnreservedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.~";
        private string m_sAccessToken = string.Empty;
        private string m_sChatterAPIEndpoint = string.Empty;
        private string m_sAuthorizeAPI = string.Empty;
        private string m_sAccessTokenAPI = string.Empty;
        private string m_sChatterAPIBase = string.Empty;
        private string m_sAPIUrl = string.Empty;
        private string m_sApiResponse = string.Empty;
        private int m_iAutoRefreshTimer = 300000;
        private int m_iAutoCompleteSearchUserCount = 50;

        #endregion

        #region Public Property

        public string AccessToken
        {
            get
            {
                return m_sAccessToken;
            }
            set
            {
                m_sAccessToken = value;
            }
        }


        public string ChatterAPIEndpoint
        {
            get
            {
                return m_sChatterAPIEndpoint;
            }
            set
            {
                m_sChatterAPIEndpoint = value;
            }
        }

        public string AuthorizeAPI
        {
            get
            {
                return m_sAuthorizeAPI;
            }
            set
            {
                m_sAuthorizeAPI = value;
            }
        }

        public string AccessTokenAPI
        {
            get
            {
                return m_sAccessTokenAPI;
            }
            set
            {
                m_sAccessTokenAPI = value;
            }
        }

        public int AutoRefreshTimer
        {
            get
            {
                return m_iAutoRefreshTimer;
            }
            set
            {
                m_iAutoRefreshTimer = value;
            }
        }

        public string ChatterAPIBase
        {
            get
            {
                return m_sChatterAPIBase;
            }
            set
            {
                m_sChatterAPIBase = value;
            }
        }

        public int AutoCompleteSearchUserCount
        {
            get
            {
                return m_iAutoCompleteSearchUserCount;
            }
            set
            {
                m_iAutoCompleteSearchUserCount = value;
            }
        }
        #endregion


        /// <summary>
        /// Get called on oAuthPage Page Load event. This function call GetAuthorizeToken() to get Authorization token
        /// Will redirect to chatter login page if user is not logged in.
        /// </summary>
        /// <returns> Authorization token </returns>
        public string GetAuthorizationLink(GlobalEntities UserEntites, string strState)
        {
            string sResponse = string.Empty;
            string sLoginUrl = string.Empty;
            try
            {
                sResponse = GetAuthorizeToken(enMethod.GET, UserEntites, strState);
                if (string.IsNullOrEmpty(sResponse))
                    return sLoginUrl;
                sLoginUrl = sResponse.Substring(sResponse.IndexOf("https"), (sResponse.IndexOf("=" + CONST_API_DISPLAY) - sResponse.IndexOf("https")));
                sLoginUrl += "=popup";
                return sLoginUrl;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Method get called from GetAuthorizationLink and returns the html text for authorization login window.
        /// </summary>
        public string GetAuthorizeToken(enMethod eMethod, GlobalEntities UserEntities, string strState)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sAuthTknFormat, AuthorizeAPI, UserEntities.ConsumerKey, UrlEncode(UserEntities.CommonCallBackURL), CONST_API_DISPLAY, HttpUtility.UrlEncode(strState));

                m_sApiResponse = WebRequest(eMethod, m_sAPIUrl);
                return m_sApiResponse;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }
        
        /// <summary>
        /// This Method gets access token in exchange with Refresh token.
        /// Prerequsite for this method is user must have refresh token.
        /// </summary>
        public string GetAccessToken(GlobalEntities UserEntities)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sAccessTknFrmRefTknFormat, AccessTokenAPI, UserEntities.ConsumerKey, UserEntities.ConsumerSecret, UserEntities.RefreshToken);
                AccessToken = GetAccToken(m_sAPIUrl, "AT").Access_Token;
                UserEntities.AccessToken = AccessToken;
                return AccessToken;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method returns access token or refresh token.
        /// </summary>
        private AccessToken GetAccToken(string URL, string sToken)
        {
            AccessToken oAccessToken = null;
            try
            {
                m_sApiResponse = WebRequest(enMethod.POST, URL);
                if (string.IsNullOrEmpty(m_sApiResponse))
                    return null;
                oAccessToken = Utility.GetObjectFromJSON<AccessToken>(m_sApiResponse);
                return oAccessToken;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method is used to Search Groups
        /// </summary>
        public List<Group> SearchGroups(string sGroupText)
        {
            GroupPage oGroupPage = null;
            List<Group> oAllGroups = new List<Group>();
            try
            {
                m_sAPIUrl = string.Format(m_sSearchGroupFormat, ChatterAPIEndpoint, ChatterAPIBase, System.Web.HttpUtility.UrlEncode(sGroupText));

                do
                {
                    oGroupPage = GetObject<GroupPage>(m_sAPIUrl, enMethod.GET);
                    oAllGroups.InsertRange(oAllGroups.Count, oGroupPage.Groups.ToList());
                    m_sAPIUrl = ChatterAPIEndpoint + oGroupPage.NextPageURL;
                } while (!string.IsNullOrEmpty(oGroupPage.NextPageURL));
                return oAllGroups;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Method gets access token in exchange with authorization token.
        /// This method gets called when user dont have refresh token.
        /// </summary>
        public AccessToken GetRefreshToken(enMethod eMethod, string sAuthToken, GlobalEntities UserEntities)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sAccessTknFrmAuthTknFormat, AccessTokenAPI, sAuthToken, UserEntities.ConsumerKey, UserEntities.ConsumerSecret, UrlEncode(UserEntities.CommonCallBackURL));
                return GetAccToken(m_sAPIUrl, "RT");
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }               

        /// <summary>
        /// This method defines HttpwebRequest object and calls to GetWebResponse
        /// </summary>
        public string WebRequest(enMethod eMethod, string URL)
        {
            //System.Net.ServicePointManager.CertificatePolicy = new CustomCertificatePolicy();
            HttpWebRequest oWebRequest = null;
            try
            {
                oWebRequest = System.Net.WebRequest.Create(URL) as HttpWebRequest;
                oWebRequest.Method = eMethod.ToString();
                oWebRequest.ServicePoint.Expect100Continue = false;
                m_sApiResponse = GetWebResponse(oWebRequest);
                oWebRequest = null;
                return m_sApiResponse;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method bypass the ssl certification Authentication.
        /// </summary>
        public bool SecureCertValCallBk(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors err)
        {
            try
            {
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// This method make actual call to server with httpweb request and get response from it.
        /// </summary>
        public string GetWebResponse(HttpWebRequest oWebRequest)
        {
            StreamReader oResponseReader = null;
            WebResponse oWebResponse = null;
            Stream oResponseStream = null;
            try
            {
                ////To By pass ssl certification Authentication

                //oWebRequest.KeepAlive = false;
                //oWebRequest.ConnectionGroupName = Guid.NewGuid().ToString();
                //ServicePointManager.ServerCertificateValidationCallback += SecureCertValCallBk;

                oWebResponse = oWebRequest.GetResponse();
                oResponseStream = oWebResponse.GetResponseStream();
                oResponseReader = new StreamReader(oResponseStream);
                m_sApiResponse = oResponseReader.ReadToEnd();
                return m_sApiResponse;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
            finally
            {
                if (oWebResponse != null)
                    oWebResponse.Close();
            }
        }

        /// <summary>
        /// Download file
        /// </summary>      
        public Stream DownloadFile(string sDownloadApiUrl)
        {
            try
            {                
                HttpWebRequest oWebRequest = null;
                HttpWebResponse oWebResponse = null;
                oWebRequest = System.Net.WebRequest.Create(sDownloadApiUrl) as HttpWebRequest;
                oWebRequest.Headers.Add("Authorization", "OAuth " + AccessToken);
                oWebRequest.ContentType = "application/x-www-form-urlencoded";
                oWebRequest.Method = enMethod.GET.ToString();
                oWebRequest.ServicePoint.Expect100Continue = false;
                oWebRequest.Timeout = 10000;
                oWebRequest.AllowWriteStreamBuffering = false;

                ////To By pass ssl certification Authentication

                //oWebRequest.KeepAlive = false;
                //oWebRequest.ConnectionGroupName = Guid.NewGuid().ToString();
                //ServicePointManager.ServerCertificateValidationCallback += SecureCertValCallBk;
                
                oWebResponse = (HttpWebResponse)oWebRequest.GetResponse();
                return oWebResponse.GetResponseStream();
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
            
        }


        /// <summary>
        /// This Method returns general information about the org users
        /// </summary>
        public OrgUserPage GetOrgUsers(string sUserName)
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT_ORG_USER_LIST, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_USERS, sUserName, AutoCompleteSearchUserCount);
                return GetObject<OrgUserPage>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Method is used to get all topics list
        /// </summary>
        public AllTopics GetTopics()
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_TOPICS);
                return GetObject<AllTopics>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Method returns general information about logged in user.
        /// </summary>
        public UserDetail GetUserProfile()
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_ME);
                return GetObject<UserDetail>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method gives the users to which current logged in user is following.
        /// </summary>
        public void GetUsersFollwing()
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_MY_FOLLOWINGS);
                m_sApiResponse = ExecuteChatterAPI(m_sAPIUrl, enMethod.GET);
                if (m_sApiResponse.Length > 0)
                {
                    //myFollowings = Utility.GetObjectFromJSON<>(sFollowings);
                }

            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This is common method
        /// </summary>
        private T GetObject<T>(string URL, enMethod oMethod)
        {
            T oObject;
            try
            {
                m_sApiResponse = ExecuteChatterAPI(URL, oMethod);
                oObject = Utility.GetObjectFromJSON<T>(m_sApiResponse);
                return oObject;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This is common method
        /// </summary>
        private T GetObject<T>(string URL, string sJSON)
        {
            T oObject;
            try
            {
                m_sApiResponse = ExecuteChatterAPI(URL, sJSON);
                oObject = Utility.GetObjectFromJSON<T>(m_sApiResponse);
                return oObject;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// Gets the available feed filters for that user
        /// </summary>        
        public FeedDirectory GetFilterList()
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_FILTER_FEEDS);
                return GetObject<FeedDirectory>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>        
        /// This method returns feeds according to the filter selected
        /// </summary>
        public FeedItemPage GetFilterFeeds(string sPageURL, bool bNextPageFeedURL)
        {
            try
            {
                if (!bNextPageFeedURL)
                    m_sAPIUrl = string.Format(SFConstants.CONST_FILTER_FORMAT, ChatterAPIEndpoint, sPageURL);
                else
                    m_sAPIUrl = string.Format(m_sGroupFeedsPageFormat, ChatterAPIEndpoint, sPageURL);

                return GetObject<FeedItemPage>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>        
        /// This method returns feeds after searching the feeds which contain the search text
        /// </summary>
        public FeedItemPage SearchFeeds(string sSearchItem)
        {
            try
            {
                m_sAPIUrl = string.Format(SFConstants.m_sSearchFeeds, ChatterAPIEndpoint, ChatterAPIBase, UrlEncode(sSearchItem));
                return GetObject<FeedItemPage>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Function deletes the comment to which context user have access.
        /// </summary>
        public string DeleteThisPost(string sFeedItemID)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sFeedItemsUpdateFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                return ExecuteChatterAPI(m_sAPIUrl, enMethod.DELETE);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Function deletes the comment to which context user have access.
        /// </summary>
        public string DeleteThisComment(string sCommentId)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sCommentDeleteFormat, ChatterAPIEndpoint, ChatterAPIBase, sCommentId);
                return ExecuteChatterAPI(m_sAPIUrl, enMethod.DELETE);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Function posts a link url and name to all chatter wall of current context user.
        /// </summary>
        public FeedItem PostLinkToMyWall(string sLink, string sUrlName, string sLinkPost, string sMentionList)
        {
            string sLinkPOSTJSON = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(sMentionList))
                {
                    m_sAPIUrl = string.Format(m_sLinkPostFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_RECORD, System.Web.HttpUtility.UrlEncode(sLink), System.Web.HttpUtility.UrlEncode(sUrlName), System.Web.HttpUtility.UrlEncode(sLinkPost));
                    return GetObject<FeedItem>(m_sAPIUrl, enMethod.POST);
                }
                else
                {
                    sLinkPOSTJSON = GetJSONForLinkPost(sMentionList, sLinkPost, sLink, sUrlName);
                    m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_RECORD);
                    return GetObject<FeedItem>(m_sAPIUrl, sLinkPOSTJSON);
                }
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method return feeds of particular group wall.
        /// </summary>
        public FeedItemPage GetGroupFeeds(string sGroupId, string sPageURL, bool bNextPageFeedURL)
        {
            FeedItemPage oFeed = null;
            try
            {
                if (!bNextPageFeedURL)
                    m_sAPIUrl = string.Format(m_sGroupFeedsFormat, ChatterAPIEndpoint, ChatterAPIBase, sGroupId);
                else
                    m_sAPIUrl = string.Format(m_sGroupFeedsPageFormat, ChatterAPIEndpoint, sPageURL);

                oFeed = GetObject<FeedItemPage>(m_sAPIUrl, enMethod.GET);

                return oFeed;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method returns feeds of particular feed item. 
        /// This method take Feed Item ID as input parameter.
        /// </summary>
        public FeedItem GetFeedItemsUpdate(string sFeedItemID)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sFeedItemsUpdateFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                return GetObject<FeedItem>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method returns list of all likes updates for particular feed item.
        /// </summary>
        public List<Like> GetFeedItemLikesUpdate(string sFeedItemID)
        {

            LikePage oLikePage = null;
            List<Like> olistAllLikes = new List<Like>();
            try
            {
                m_sAPIUrl = string.Format(m_sLikesFroamt, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                do
                {
                    oLikePage = GetObject<LikePage>(m_sAPIUrl, enMethod.GET);
                    olistAllLikes.InsertRange(olistAllLikes.Count, oLikePage.Likes.ToList());
                    m_sAPIUrl = ChatterAPIEndpoint + oLikePage.NextPageURL;
                } while (!string.IsNullOrEmpty(oLikePage.NextPageURL));

                return olistAllLikes;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method returns list of all recent comments for particular feed item.
        /// </summary>
        public List<Comments> GetFeedItemCommentsUpdate(string sFeedItemID)
        {
            CommentPage oCommentPage = null;
            List<Comments> olistAllComments = new List<Comments>();
            try
            {
                m_sAPIUrl = string.Format(m_sFeedCommentsUpdateFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                do
                {
                    oCommentPage = GetObject<CommentPage>(m_sAPIUrl, enMethod.GET);

                    olistAllComments.InsertRange(0, oCommentPage.Comments.ToList());
                    m_sAPIUrl = ChatterAPIEndpoint + oCommentPage.NextPageURL;
                } while (!string.IsNullOrEmpty(oCommentPage.NextPageURL));

                return olistAllComments;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method returns list of all recent comments for particular feed item.
        /// </summary>
        public CommentPage GetUpdatedFeedComments(string sFeedItemID)
        {
            CommentPage oCommentPage = null;
            try
            {
                m_sAPIUrl = string.Format(m_sFeedCommentsUpdateFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                oCommentPage = GetObject<CommentPage>(m_sAPIUrl, enMethod.GET);

                return oCommentPage;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method returns logged in users recent wall post.
        /// </summary>
        /// <returns></returns>
        public UserStatus GetMyStatus()
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_MY_STATUS);
                return GetObject<UserStatus>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Function posts a link url and name to all chatter wall of current context user.
        /// </summary>
        public FeedItem PostLinkToGroupWall(string sLink, string sUrlName, string sLinkPost, string sGroupID, string sMentionList)
        {
            string sLinkPOSTJSON = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(sMentionList))
                {
                    m_sAPIUrl = string.Format(m_sGroupLinkPostFormat, ChatterAPIEndpoint, ChatterAPIBase, sGroupID, System.Web.HttpUtility.UrlEncode(sLink), System.Web.HttpUtility.UrlEncode(sUrlName), System.Web.HttpUtility.UrlEncode(sLinkPost));
                    return GetObject<FeedItem>(m_sAPIUrl, enMethod.POST);
                }
                else
                {
                    sLinkPOSTJSON = GetJSONForLinkPost(sMentionList, sLinkPost, sLink, sUrlName);
                    m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_RECORD);
                    return GetObject<FeedItem>(m_sAPIUrl, sLinkPOSTJSON);
                }
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method post new status to group wall.
        /// This status will be posted by chatter web part on behalf of current logged in user.
        /// </summary>
        public FeedItem PostToGroupWall(string sGroupID, string sStatus, string sMentionList)
        {
            string sJSONInput = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(sMentionList))
                {
                    m_sAPIUrl = string.Format(m_sUpdateStatusAtGroupWall, ChatterAPIEndpoint, ChatterAPIBase, sGroupID, System.Web.HttpUtility.UrlEncode(sStatus));
                    return GetObject<FeedItem>(m_sAPIUrl, enMethod.POST);
                }
                else
                {
                    sJSONInput = GetJSON(sMentionList, sStatus);
                    m_sAPIUrl = string.Format(m_sPostToGroupWallFormat, ChatterAPIEndpoint, ChatterAPIBase, sGroupID);
                    return GetObject<FeedItem>(m_sAPIUrl, sJSONInput);
                }
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method likes a particular feed item.
        /// </summary>
        public Like LikeItem(string sFeedItemID)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sLikesFroamt, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                return GetObject<Like>(m_sAPIUrl, enMethod.POST);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method unlikes feed item which needs a like ID as input parameter.
        /// </summary>
        public void UnLikeItem(string sLikeId)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sUnLikeFormat, ChatterAPIEndpoint, ChatterAPIBase, sLikeId);
                m_sApiResponse = ExecuteChatterAPI(m_sAPIUrl, enMethod.DELETE);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method post a comment on particular feed item.
        /// </summary>
        public Comments PostComment(string sFeedItemID, string sMentionList, string sComment)
        {
            string sJSONInput = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(sMentionList))
                {
                    m_sAPIUrl = string.Format(m_sCommentFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID, System.Web.HttpUtility.UrlEncode(sComment));
                    return GetObject<Comments>(m_sAPIUrl, enMethod.POST);
                }
                else
                {
                    sJSONInput = GetJSON(sMentionList, sComment);
                    m_sAPIUrl = string.Format(m_sCommentPostFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_FEEDS, sFeedItemID);
                    return GetObject<Comments>(m_sAPIUrl, sJSONInput);
                }
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This function will upload the file to chatter with the description and Post data. 
        /// This method get called to upload file from SharePoint.
        /// </summary>
        public FeedItem UploadFile(byte[] btFileData, string sFileName, string sDescription, string sPostText, string sGroupID, string sMentionList)
        {
            Dictionary<string, object> oPostParameters = new Dictionary<string, object>();
            string sFileAttachmentJSON;
            try
            {
                sFileAttachmentJSON = GetJSONForFilePost(sMentionList, sPostText, sDescription, sFileName);

                // Generate post objects
                oPostParameters = new Dictionary<string, object>();
                oPostParameters.Add("feedItemFileUpload", new FormUpload.FileParameter(btFileData, sFileName, "application/json"));
                oPostParameters.Add("Body", sFileAttachmentJSON);

                // Create request and receive response
                string sPostURL = string.Empty;
                if (string.IsNullOrEmpty(sGroupID))
                    sPostURL = string.Format(m_sUploadFileToMyWall, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_FILE_UPLOAD);
                else
                    sPostURL = string.Format(m_sUploadFileToGroupWallFormat, ChatterAPIEndpoint, ChatterAPIBase, sGroupID);

                m_sApiResponse = FormUpload.MultipartFormDataPost(sPostURL, AccessToken, oPostParameters);

                FeedItem oFeedItem = Utility.GetObjectFromJSON<FeedItem>(m_sApiResponse);

                return oFeedItem;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Handels all chatter API with http method POST
        /// </summary>
        public string ExecuteChatterAPI(string URL, enMethod eMethod)
        {
            HttpWebRequest oWebRequest = null;
            try
            {
                oWebRequest = System.Net.WebRequest.Create(URL) as HttpWebRequest;
                oWebRequest.Headers.Add("Authorization", "OAuth " + AccessToken);
                oWebRequest.ContentType = "application/x-www-form-urlencoded";
                oWebRequest.Method = eMethod.ToString();
                oWebRequest.ServicePoint.Expect100Continue = false;
                m_sApiResponse = GetWebResponse(oWebRequest);
                oWebRequest = null;
                return m_sApiResponse;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Handels all chatter API with http method POST
        /// </summary>
        public string ExecuteChatterAPI(string URL, string sData)
        {
            HttpWebRequest oWebRequest = null;
            try
            {
                oWebRequest = System.Net.WebRequest.Create(URL) as HttpWebRequest;
                oWebRequest.Headers.Add("Authorization", "OAuth " + AccessToken);
                oWebRequest.ContentType = "application/json";
                oWebRequest.Method = enMethod.POST.ToString();
                oWebRequest.MaximumAutomaticRedirections = 10;
                oWebRequest.PreAuthenticate = true;
                oWebRequest.AllowAutoRedirect = true;
                oWebRequest.Timeout = 1000 * 1000;
                oWebRequest.KeepAlive = true;

                byte[] data = Encoding.UTF8.GetBytes(sData);

                oWebRequest.ContentLength = data.Length;

                using (Stream requestStream = oWebRequest.GetRequestStream())
                {
                    requestStream.Write(data, 0, data.Length);
                    requestStream.Close();
                }
                m_sApiResponse = GetWebResponse(oWebRequest);
                oWebRequest = null;
                return m_sApiResponse;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }



        /// <summary>
        /// This is a different Url Encode implementation since the default .NET one outputs the percent encoding in lower case.
        /// While this is not a problem with the percent encoding spec, it is used in upper case throughout oChatterRESTAPI
        /// </summary>
        public string UrlEncode(string value)
        {
            StringBuilder result = new StringBuilder();
            try
            {
                foreach (char symbol in value)
                {
                    if (m_sUnreservedChars.IndexOf(symbol) != -1)
                    {
                        result.Append(symbol);
                    }
                    else
                    {
                        result.Append('%' + String.Format("{0:X2}", (int)symbol));
                    }
                }

                return result.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This function will post status to context users wall.
        /// </summary>
        public FeedItem PostToMyWall(string sMentionList, string sStatus)
        {
            string sJSONInput = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(sMentionList))
                {
                    m_sAPIUrl = string.Format(m_sPostToMyWallFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_UPDATE_MY_STATUS, System.Web.HttpUtility.UrlEncode(sStatus));
                    return GetObject<FeedItem>(m_sAPIUrl, enMethod.POST);
                }
                else
                {
                    sJSONInput = GetJSON(sMentionList, sStatus);
                    m_sAPIUrl = string.Format(m_sPostFeedFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_POST_UPDATE_MY_STATUS);
                    return GetObject<FeedItem>(m_sAPIUrl, sJSONInput);
                }
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Method is used to get JSON from input text
        /// </summary>
        public string GetJSON(string sMentionList, string sFeedText)
        {
            string sJSONOutPut = string.Empty;
            string sJSONForMenstion = string.Empty;
            try
            {
                // Get JSON for input Mention Text
                sJSONForMenstion = GetJSONForFeedText(sMentionList, sFeedText);

                // Append Messagesegments text
                sJSONOutPut = string.Format(m_sThreeParametersFormat, @"{ ""body"" :{""messageSegments"" : ", sJSONForMenstion, @"}}");
                return sJSONOutPut;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }

        }

        /// <summary>
        /// Method is used to Get JSON For Feed Text
        /// </summary>
        public string GetJSONForFeedText(string sMentionList, string sFeedText)
        {
            string sPattern = string.Empty;
            string[] sPatternResult = null;
            int iSearchResultIndex = -1;
            List<MentionUser> oMentionUserList = new List<MentionUser>();
            List<MsgSegForMention> oMessageSegments = new List<MsgSegForMention>();
            MentionUserList oMentionUserInfo = new MentionUserList();
            JavaScriptSerializer oJSSerializer = new JavaScriptSerializer();
            try
            {
                sMentionList = string.Format(m_sThreeParametersFormat, @"{""MentionUserInfo"" : [", sMentionList, "]}");
                oMentionUserInfo = Utility.GetObjectFromJSON<MentionUserList>(sMentionList);
                oMentionUserList = oMentionUserInfo.MentionUserInfo.ToList();

                var delimiters = oMentionUserList.Select(d => d.UserName);
                sPattern = string.Format(m_sThreeParametersFormat, "(", String.Join("|", delimiters.Select(d => Regex.Escape(HttpUtility.HtmlDecode(d))).ToArray()), ")");
                sPatternResult = Regex.Split(sFeedText, sPattern);

                foreach (string sResult in sPatternResult)
                {
                    if (string.IsNullOrEmpty(sResult))
                    {
                        continue;
                    }
                    iSearchResultIndex = oMentionUserList.FindIndex(Mention => HttpUtility.HtmlDecode(Mention.UserName) == sResult);

                    if (iSearchResultIndex >= 0)
                    {
                        Mention oMention = new Mention();
                        oMention.type = CONST_MENTION;
                        oMention.id = oMentionUserList[iSearchResultIndex].ID;
                        oMessageSegments.Add(oMention);
                    }
                    else
                    {
                        Text oText = new Text();
                        oText.type = CONST_TEXT;
                        oText.text = sResult;
                        oMessageSegments.Add(oText);
                    }
                }

                return oJSSerializer.Serialize(oMessageSegments);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }

        }

        /// <summary>
        /// Method is used to Get JSON For Link POST
        /// </summary>
        public string GetJSONForLinkPost(string sMentionList, string sFeedText, string Url, string UrlName)
        {
            string sLinkAttachementJSON = string.Empty;
            string sJSONOutPut = string.Empty;
            string sJSONForMenstion = string.Empty;
            LinkAttachement oLinkAttachment = new LinkAttachement();
            JavaScriptSerializer oJSSerializer = new JavaScriptSerializer();
            try
            {
                // Get JSON for Mention
                sJSONForMenstion = GetJSONForFeedText(sMentionList, sFeedText);

                // Get JSON for Link Post
                oLinkAttachment.Url = Url;
                oLinkAttachment.UrlName = UrlName;
                sLinkAttachementJSON = oJSSerializer.Serialize(oLinkAttachment);

                // Append Feed Text JSON and Link JSON;
                sJSONOutPut = string.Format(m_sThreeParametersFormat, @"{ ""body"" :{""messageSegments"" : ", sJSONForMenstion, @"},""attachment"" :" + sLinkAttachementJSON + "}");
                return sJSONOutPut;

            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Method is used to Get JSON For File POST
        /// </summary>
        public string GetJSONForFilePost(string sMentionList, string sFeedText, string sDesc, string sFileName)
        {
            string sFileAttachementJSON = string.Empty;
            string sJSONOutPut = string.Empty;
            string sJSONForMenstion = string.Empty;
            FileAttachemnt oFileAttachment = new FileAttachemnt();
            JavaScriptSerializer oJSSerializer = new JavaScriptSerializer();
            try
            {
                // Get JSON for Mention
                sJSONForMenstion = GetJSONForFeedText(sMentionList, sFeedText);

                // Get JSON for File Post
                oFileAttachment.Desc = sDesc;
                oFileAttachment.FileName = sFileName;
                sFileAttachementJSON = oJSSerializer.Serialize(oFileAttachment);

                // Append Feed Text JSON and Link JSON;
                sJSONOutPut = string.Format(m_sThreeParametersFormat, @"{ ""body"" :{""messageSegments"" : ", sJSONForMenstion, @"},""attachment"" :" + sFileAttachementJSON + "}");
                return sJSONOutPut;

            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// 
        /// </summary>
        public void ClearMyStatus()
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_MY_STATUS);
                m_sApiResponse = ExecuteChatterAPI(m_sAPIUrl, enMethod.DELETE);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method gives list of all chatter groups to which current logged in user belongs to
        /// </summary>       
        public List<Group> GetMyGroups()
        {
            GroupPage oGroupPage = null;
            List<Group> oAllGroups = new List<Group>();
            try
            {
                m_sAPIUrl = string.Format(CONST_API_BASIC_FORMAT, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_MY_GROUPS);

                do
                {
                    oGroupPage = GetObject<GroupPage>(m_sAPIUrl, enMethod.GET);
                    oAllGroups.InsertRange(oAllGroups.Count, oGroupPage.Groups.ToList());
                    m_sAPIUrl = ChatterAPIEndpoint + oGroupPage.NextPageURL;
                } while (!string.IsNullOrEmpty(oGroupPage.NextPageURL));
                return oAllGroups;
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method is used to get Group Information
        /// </summary>
        public Group GetGroupInformation(string sGroupID)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sGroupInfoFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_CHATTER_GROUPS, sGroupID);
                return GetObject<Group>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This method is used to follow user
        /// </summary>
        public Subscription FollowUser(string sUserID)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sFolloweUserFormat, ChatterAPIEndpoint, ChatterAPIBase, CONST_API_FOLLOW_RECORD, sUserID);
                return GetObject<Subscription>(m_sAPIUrl, enMethod.POST);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// Method is used to unfollow user as per given subscriptionID
        /// </summary>
        public void UnFollowUser(string sSubscriptionURL)
        {
            try
            {
                m_sAPIUrl = string.Format(m_sUnFollowFormat, ChatterAPIEndpoint, sSubscriptionURL);
                m_sApiResponse = ExecuteChatterAPI(m_sAPIUrl, enMethod.DELETE);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }


        /// <summary>
        /// This method returns all User Details
        /// </summary>        
        public BatchResults GetUserList(string userIdList)
        {
            try
            {
                m_sAPIUrl = string.Format(CONST_API_USERBATCH, ChatterAPIEndpoint, ChatterAPIBase, userIdList);
                return GetObject<BatchResults>(m_sAPIUrl, enMethod.GET);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }

        /// <summary>
        /// This Method is used post a private message to specific users
        /// </summary>
        public Message PostPrivateMessage(string sUserIdList, string sMessageBody)
        {
            PrivateMessage oPrivateMessage = new PrivateMessage();
            JavaScriptSerializer oJSSerializer = new JavaScriptSerializer();
            string sOutPut = string.Empty;
            try
            {
                oPrivateMessage.body = sMessageBody;
                sOutPut = oJSSerializer.Serialize(oPrivateMessage);

                sUserIdList = sUserIdList.Replace(",", "\",\"");
                string sJSONOutPut = sOutPut.Substring(0, sOutPut.Length - 2) + @""",""recipients"" : [""" + sUserIdList + @"""]}";
                m_sAPIUrl = string.Format(m_sPostPrivateMessage, ChatterAPIEndpoint, ChatterAPIBase);
                return GetObject<Message>(m_sAPIUrl, sJSONOutPut);
            }
            catch (WebException) { throw; }
            catch (Exception) { throw; }
        }
    }
}
