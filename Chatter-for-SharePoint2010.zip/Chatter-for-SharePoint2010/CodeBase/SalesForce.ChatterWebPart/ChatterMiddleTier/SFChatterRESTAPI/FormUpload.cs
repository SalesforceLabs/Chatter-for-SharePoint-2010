﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Net;

using System.IO;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    public static class FormUpload
    {
        private static readonly Encoding encoding = Encoding.Default;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sPostUrl"></param>
        /// <param name="sAccessToken"></param>
        /// <param name="dicPostParameters"></param>
        /// <returns></returns>
        public static string MultipartFormDataPost(string sPostUrl, string sAccessToken, Dictionary<string, object> dicPostParameters)
        {
            try
            {
                string sFormDataBoundary = "-----------------------------28947758029299";
                string sContentType = "multipart/form-data; boundary=" + sFormDataBoundary;

                byte[] btFormData = GetMultipartFormData(dicPostParameters, sFormDataBoundary);

                return PostForm(sPostUrl, sAccessToken, sContentType, btFormData);
            }
            catch (WebException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sPostUrl"></param>
        /// <param name="sAccessToken"></param>
        /// <param name="sContentType"></param>
        /// <param name="btFormData"></param>
        /// <returns></returns>
        private static string PostForm(string sPostUrl, string sAccessToken, string sContentType, byte[] btFormData)
        {
            StreamReader oResponseReader = null;
            WebResponse oWebResponse = null;
            Stream oResponseStream = null;
            string sApiResponse = string.Empty;
            try
            {
                HttpWebRequest oRrequest = WebRequest.Create(sPostUrl) as HttpWebRequest;
                if (oRrequest == null)
                {
                    throw new NullReferenceException("Request is not a http request");
                }
                // Set up the request properties
                oRrequest.Method = "POST";
                oRrequest.ContentType = sContentType;
                oRrequest.Headers.Add("Authorization", "OAuth " + sAccessToken);

                oRrequest.MaximumAutomaticRedirections = 10;
                oRrequest.PreAuthenticate = true;
                oRrequest.AllowAutoRedirect = true;
                oRrequest.Timeout = 1000 * 1000;
                oRrequest.KeepAlive = true;

                using (Stream requestStream = oRrequest.GetRequestStream())
                {
                    requestStream.Write(btFormData, 0, btFormData.Length);
                    requestStream.Close();
                }

                oWebResponse = oRrequest.GetResponse();
                oResponseStream = oWebResponse.GetResponseStream();
                oResponseReader = new StreamReader(oResponseStream);
                sApiResponse = oResponseReader.ReadToEnd();
                return sApiResponse;
            }
            catch (WebException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dicPostParameters"></param>
        /// <param name="sBoundary"></param>
        /// <returns></returns>
        private static byte[] GetMultipartFormData(Dictionary<string, object> dicPostParameters, string sBoundary)
        {
            string postData = string.Empty;
            try
            {
                Stream formDataStream = new System.IO.MemoryStream();
                string sFooter = "\r\n--" + sBoundary + "--\r\n";

                foreach (var vParameter in dicPostParameters)
                {
                    if (vParameter.Value is FileParameter)
                    {
                        FileParameter fileToUpload = (FileParameter)vParameter.Value;

                        // Add just the first part of this param, since we will write the file data directly to the Stream
                        string header = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"{1}\"; filename=\"{2}\";\r\nContent-Type: {3}\r\n\r\n",
                            sBoundary,
                            vParameter.Key,
                            fileToUpload.FileName ?? vParameter.Key,
                            fileToUpload.ContentType ?? "application/octet-stream");

                        formDataStream.Write(encoding.GetBytes(header), 0, header.Length);

                        // Write the file data directly to the Stream, rather than serializing it to a string.
                        formDataStream.Write(fileToUpload.File, 0, fileToUpload.File.Length);
                        // Thanks to feedback from commenters, add a CRLF to allow multiple files to be upload
                        formDataStream.Write(encoding.GetBytes("\r\n"), 0, 2);
                    }
                    else
                    {
                        postData = string.Format("--{0}\r\nContent-Disposition:  form-data; name=\"{1}\";\r\nContent-Type: application/json; \r\n\r\n{2}\r\n\r\n",
                           sBoundary,
                           vParameter.Key,
                           vParameter.Value);
                        formDataStream.Write(encoding.GetBytes(postData), 0, postData.Length);
                    }
                }

                formDataStream.Write(encoding.GetBytes(sFooter), 0, sFooter.Length);

                // Dump the Stream into a byte[]
                formDataStream.Position = 0;
                byte[] btFormData = new byte[formDataStream.Length];

                formDataStream.Read(btFormData, 0, btFormData.Length);
                formDataStream.Close();
                return btFormData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class FileParameter
        {
            public byte[] File { get; set; }
            public string FileName { get; set; }
            public string ContentType { get; set; }
            public FileParameter(byte[] file) : this(file, null) { }
            public FileParameter(byte[] file, string filename) : this(file, filename, null) { }
            public FileParameter(byte[] file, string filename, string contenttype)
            {
                File = file;
                FileName = filename;
                ContentType = contenttype;
            }
        }
    }
}