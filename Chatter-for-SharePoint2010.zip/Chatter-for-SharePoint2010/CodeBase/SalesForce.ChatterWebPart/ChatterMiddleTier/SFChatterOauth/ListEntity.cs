﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// This entity class is used to get all the Consumer Key list fields
    /// </summary>
    public static class ConsumerKeyListEntity
    {
        #region Constant variables
        const string LIST_CONSUMER_KEY = "Org Remote Access Details";
        const string LIST_CONSUMER_KEY_DESC = "This list is used to store all the Consumer Keys information for the chatter API";
        //const string CONST_COL_CONSUMER_KEY = "ConsumerKey"; //This column would be look up column in User And Refresh Token Details list 
        //const string CONST_COL_CONSUMER_SECRET = "ConsumerSecret";
        const string COL_CALLBACK_URL_DISPLAYNAME = "CallBack Url";
        const string COL_GROUP_NAME = "Groups";
        const string COL_ALLOW_TO_POST_FILE = "AllowToPostFile";
        #endregion

        #region Properties
        /// <summary>
        /// Gets the Consumer Key list title
        /// </summary>
        public static string ConsumerKeyList
        {
            get { return LIST_CONSUMER_KEY; }
        }

        /// <summary>
        /// Gets the Consumer Key list description
        /// </summary>
        public static string ConsumerKeyListDesc
        {
            get { return LIST_CONSUMER_KEY_DESC; }
        }

        /// <summary>
        /// Gets the name of Consumer Key column
        /// </summary>
        //public static string ConsumerKey
        //{
        //    get { return CONST_COL_CONSUMER_KEY; }
        //}
        
        /// <summary>
        /// Gets the name of Consumer Secret column
        /// </summary>
        //public static string ConsumerSecret
        //{
        //    get { return CONST_COL_CONSUMER_SECRET; }
        //}

        /// <summary>
        ///Gets the display name name of CallBackURL column. 
        /// </summary>
        public static string CallbackURLDisplayName
        {
            get { return COL_CALLBACK_URL_DISPLAYNAME; }
        }

        /// <summary>
        ///Gets the name of Groups column. 
        /// </summary>
        public static string Groups
        {
            get { return COL_GROUP_NAME; }
        }

        /// <summary>
        ///Gets the name of AllowToPostFile column. 
        /// </summary>
        public static string AllowToPostFile
        {
            get { return COL_ALLOW_TO_POST_FILE; }
        }
        #endregion
    }

    /// <summary>
    /// This entity class is used to get all the User And Refresh Token Details list fields
    /// </summary>
    public static class UserRefreshTokenListEntity
    {
        #region Constant variables
        const string LIST_USER_AND_REFRESHTOKEN_DETAILS = "User Access Details";
        const string LIST_USER_AND_REFRESHTOKEN_DETAILS_DESC = "This list is used to store the information for the SharePoint User and Refresh Token against the Consumer Key";
        const string CONST_COL_USERID = "UserID";
        const string CONST_COL_REFRESH_TOKEN = "RefreshToken";
        const string CONST_COL_GROUP_ID = "GroupID";
        //const string CONST_COL_CONSUMER_KEY = "ConsumerKey";
        const string CONST_COL_INSTANCE_URL = "InstanceUrl";
        const string CONST_COL_ACCESS_TOKEN = "AccessToken";
        const string CONST_COL_WEBPART_URL = "WebpartUrl";
        #endregion

        #region Properties
        /// <summary>
        /// Gets the User And Refresh Token Details list 
        /// </summary>
        public static string UserAndRefreshTokenDetailsList
        {
            get { return LIST_USER_AND_REFRESHTOKEN_DETAILS; }
        }
        
        /// <summary>
        /// Gets the User And Refresh Token Details list description
        /// </summary>
        public static string UserAndRefreshTokenDetailsListDesc
        {
            get { return LIST_USER_AND_REFRESHTOKEN_DETAILS_DESC; }
        }
        
        /// <summary>
        ///Gets the name of UserID column
        /// </summary>
        public static string UserID
        {
            get { return CONST_COL_USERID; }
        }
        
        /// <summary>
        ///Gets the name of RefreshToken column
        /// </summary>
        public static string RefreshToken
        {
            get { return CONST_COL_REFRESH_TOKEN; }
        }
        
        /// <summary>
        ///Gets the name of GroupID column
        /// </summary>
        public static string GroupID
        {
            get { return CONST_COL_GROUP_ID; }
        }
        
        /// <summary>
        ///Gets the name of ConsumerKey column
        /// </summary>
        //public static string ConsumerKey//This column would be look up column from Consumer Key Details list 
        //{
        //    get { return CONST_COL_CONSUMER_KEY; }
        //}

        /// <summary>
        /// Gets the name of InstanceUrl column 
        /// </summary>
        public static string InstanceUrl
        {
            get { return CONST_COL_INSTANCE_URL; }
        }
        
        /// <summary>
        ///Gets the name of AccessToken column
        /// </summary>
        public static string AccessToken
        {
            get { return CONST_COL_ACCESS_TOKEN; }
        }

        /// <summary>
        ///Gets the name of WebpartUrl column
        /// </summary>
        public static string WebpartUrl
        {
            get { return CONST_COL_WEBPART_URL; }
        }
                
        #endregion
    }
}
