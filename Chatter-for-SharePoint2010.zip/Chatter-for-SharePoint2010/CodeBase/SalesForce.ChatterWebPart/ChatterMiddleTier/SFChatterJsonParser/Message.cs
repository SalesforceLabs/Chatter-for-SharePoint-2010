﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class Message
    {
        #region Private Members

        private FeedBody _body = null;
        private string _sendDate = string.Empty;
        private string _conversationId = string.Empty;
        private string _conversationUrl = string.Empty;
        private string _id = string.Empty;
        private UserSummary[] _recipients = null;
        private UserSummary _sender = null;
        private string _url = string.Empty;

        #endregion

        #region Properties

        public FeedBody Body
        {
            get
            {
                return _body;
            }
            set
            {
                _body = value;
            }
        }

        public string SendDate
        {
            get
            {
                return _sendDate;
            }
            set
            {
                _sendDate = value;
            }
        }

        public string ConversationId
        {
            get
            {
                return _conversationId;
            }
            set
            {
                _conversationId = value;
            }
        }

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public UserSummary[] Recipients
        {
            get
            {
                return _recipients;
            }
            set
            {
                _recipients = value;
            }
        }

        public UserSummary Sender
        {
            get
            {
                return _sender;
            }
            set
            {
                _sender = value;
            }
        }

        public string URL
        {
            get
            {
                return _url;
            }
            set
            {
                _url = value;
            }
        }


        #endregion
    }
}
