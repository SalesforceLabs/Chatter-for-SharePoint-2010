﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class BatchResultItem
    {
        private object _result;


        public object Result
        {
            get
            {
                return _result;
            }
            set
            {
                if (string.Compare(value.ToString(), "System.Object[]", true) != 0)
                {
                    _result = value;
                }
            }
        }

    }
}
