﻿using System;
using System.Collections.Generic;



namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class RecordSummary
    {
        #region private members
        private string _id = string.Empty;
        private string _name = string.Empty;
        private string _type = string.Empty;
        private string _url = string.Empty;

        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public string URL 
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        #endregion
    }
}
