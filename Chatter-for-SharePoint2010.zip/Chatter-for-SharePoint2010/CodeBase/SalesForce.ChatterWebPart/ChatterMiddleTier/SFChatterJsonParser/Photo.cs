﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// Class is used to get Photo Information
    /// </summary>
    [Serializable]
    public class Photo
    {
        #region Private Members

        private string _smallPhotoURL = string.Empty;

        // Comment out unwanted property
        //private string _largePhotoURL = string.Empty;

        #endregion

        #region Properties

        public string SmallPhotoURL
        {
            get
            {
                return _smallPhotoURL;
            }
            set
            {
                _smallPhotoURL = value;
            }
        }
        //public string LargePhotoURL
        //{
        //    get
        //    {
        //        return _largePhotoURL;
        //    }
        //    set
        //    {
        //        _largePhotoURL = value;
        //    }
        //}

        #endregion
    }
}