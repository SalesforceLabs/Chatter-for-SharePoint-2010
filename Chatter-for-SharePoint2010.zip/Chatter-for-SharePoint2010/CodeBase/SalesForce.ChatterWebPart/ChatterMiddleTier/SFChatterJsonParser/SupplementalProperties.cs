﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// class is used to get supplemental properties
    /// </summary>
    [Serializable]
    public class SupplementalProperties
    {
        #region private members

        private string _type = string.Empty;
        private DataContent _data = null;

        #endregion

        #region Properties

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public DataContent Data
        {
            get
            {
                return _data;
            }
            set
            {
                _data = value;
            }
        }

        #endregion
    }
}