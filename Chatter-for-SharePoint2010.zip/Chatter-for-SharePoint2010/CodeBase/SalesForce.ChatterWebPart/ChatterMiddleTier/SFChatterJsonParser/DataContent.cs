﻿using System;
using System.Collections.Generic;

using System.Web;

namespace SalesForce.ChatterMiddleTier
{
    /// <summary>
    /// class is used to get data content 
    /// </summary>
    [Serializable]
    public class DataContent
    {
        #region Privae members

        private string _id = string.Empty;
        private string _title = string.Empty;
        private string _description = string.Empty;
        private string _fileType = string.Empty;

        // Comment out unwanted property
        //private bool _hasImagePreview = false;
        //private bool _hasPDFPreview = false;
        //private string _mimeType = string.Empty;
        //private string _versionID = string.Empty;
        //private string _downLoadURL = string.Empty;
        //private string _fileSize = string.Empty;
        //private string _url = string.Empty;

        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }

        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }

        public string FileType
        {
            get
            {
                return _fileType;
            }
            set
            {
                _fileType = value;
            }
        }

        //public string FileSize
        //{
        //    get
        //    {
        //        return _fileSize;
        //    }
        //    set
        //    {
        //        _fileSize = value;
        //    }
        //}
        

        //public string URL
        //{
        //    get
        //    {
        //        return _url;
        //    }
        //    set
        //    {
        //        _url = value;
        //    }
        //}
        //public string VersionID
        //{
        //    get
        //    {
        //        return _versionID;
        //    }
        //    set
        //    {
        //        _versionID = value;
        //    }
        //}

        //public string DownLoadURL
        //{
        //    get
        //    {
        //        return _downLoadURL;
        //    }
        //    set
        //    {
        //        _downLoadURL = value;
        //    }
        //}
        //public bool HasImagePreview
        //{
        //    get
        //    {
        //        return _hasImagePreview;
        //    }
        //    set
        //    {
        //        _hasImagePreview = value;
        //    }
        //}

        //public bool HasPDFPreview
        //{
        //    get
        //    {
        //        return _hasPDFPreview;
        //    }
        //    set
        //    {
        //        _hasPDFPreview = value;
        //    }
        //}

        //public string MimeType
        //{
        //    get
        //    {
        //        return _mimeType;
        //    }
        //    set
        //    {
        //        _mimeType = value;
        //    }
        //}
        #endregion
    }
}