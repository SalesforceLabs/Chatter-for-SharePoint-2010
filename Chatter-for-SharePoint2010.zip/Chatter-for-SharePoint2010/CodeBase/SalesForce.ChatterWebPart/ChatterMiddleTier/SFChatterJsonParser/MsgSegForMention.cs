﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class MsgSegForMention
    {
        #region Private Memebers

        private string _type = string.Empty;

        #endregion

        #region

        public string type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        #endregion

    }
}
