﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class Subscription
    {
        #region Private Members

        private string _id = string.Empty;
        private UserSummary _subject = null;
        private UserSummary _subscriber = null;

        // Comment out unwanted property
        //private string _url = string.Empty;

        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public UserSummary Subject
        {
            get
            {
                return _subject;
            }
            set
            {
                _subject = value;
            }
        }

        public UserSummary Subscriber
        {
            get
            {
                return _subscriber;
            }
            set
            {
                _subscriber = value;
            }

        }

        //public string URL
        //{
        //    get
        //    {
        //        return _url;
        //    }
        //    set
        //    {
        //        _url = value;
        //    }
        //}

        #endregion
    }
}
