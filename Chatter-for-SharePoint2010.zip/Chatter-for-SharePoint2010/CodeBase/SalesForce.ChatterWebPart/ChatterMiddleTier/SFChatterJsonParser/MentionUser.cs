﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public  class MentionUser
    {
        #region Private Memebers

        private string _id = string.Empty;
        private string _userName = string.Empty;

        #endregion

        #region Properties

        public string ID
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string UserName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
            }
        }
        #endregion
    }
}
