﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesForce.ChatterMiddleTier
{
    [Serializable]
    public class MentionUserList
    {
        #region Private Memebers

        private MentionUser[] _MentionUserInfo = null;
       

        #endregion

        #region Properties

        public MentionUser[] MentionUserInfo
        {
            get
            {
                return _MentionUserInfo;
            }
            set
            {
                _MentionUserInfo = value;
            }
        }

        #endregion
    }
}