Add-PsSnapin Microsoft.SharePoint.PowerShell

Write-Host ''
Write-Host 'Powershell Script will initialize parameters'
$CurrentDir=$args[0]

$oldChatterWebpartWSP="chatterwebpart.wsp"
$oldmysiteChatterWSP="sfmysitechatterwp.wsp"

$logfile=$CurrentDir + "\log.log"

Start-Transcript $logfile

Write-Host ''
Write-Host 'Powershell Script will now retract old chatter team site web part solution:' $oldChatterWebpartWSP
#Removing chatterwebpart.wsp#
$SolutionTocheck = Get-SPSolution -identity $oldChatterWebpartWSP -ErrorAction:SilentlyContinue
if ($SolutionToCheck)
{
if ($SolutionToCheck.Deployed)
{
 write-host "Retracting Solution: " $oldChatterWebpartWSP
 if ($SolutionToCheck.ContainsWebApplicationResource)
 {
  Uninstall-SPSolution -identity $SolutionToCheck -allwebapplications -Confirm:$false
 }
 else
 {
  Uninstall-SPSolution -identity $SolutionToCheck -Confirm:$false
 }
}
while ($SolutionToCheck.Deployed)
{
 start-sleep -s 15
 write-host "Waiting for Retraction to Complete"
}
start-sleep -s 15
write-host "Deleting Solution: " $oldChatterWebpartWSP
Remove-SPSolution $SolutionToCheck -Confirm:$false
}


Write-Host ''
Write-Host 'Powershell Script will now retract old chatter my site web part solution:' $oldmysiteChatterWSP
#Removing sfmysitechatterwp.wsp#
$SolutionTocheck = Get-SPSolution -identity $oldmysiteChatterWSP -ErrorAction:SilentlyContinue
if ($SolutionToCheck)
{
if ($SolutionToCheck.Deployed)
{
 write-host "Retracting Solution: " $oldmysiteChatterWSP
 if ($SolutionToCheck.ContainsWebApplicationResource)
 {
  Uninstall-SPSolution -identity $SolutionToCheck -allwebapplications -Confirm:$false
 }
 else
 {
  Uninstall-SPSolution -identity $SolutionToCheck -Confirm:$false
 }
}
while ($SolutionToCheck.Deployed)
{
 start-sleep -s 15
 write-host "Waiting for Retraction to Complete"
}
start-sleep -s 15
write-host "Deleting Solution: " $oldmysiteChatterWSP
Remove-SPSolution $SolutionToCheck -Confirm:$false
}


Write-Host ''
Write-Host 'Salesforce chatter web part solution gets cleaned successfully'

Write-Host ''
Stop-Transcript

Remove-PsSnapin Microsoft.SharePoint.PowerShell