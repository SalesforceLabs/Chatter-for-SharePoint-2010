Add-PsSnapin Microsoft.SharePoint.PowerShell

Write-Host 'Powershell Script will initialize parameters'
$CurrentDir=$args[0]
$solutionName="SFChatterWebParts.wsp"
$middleTierWSP="ChatterMiddleTier.wsp"
$SolutionPath=$CurrentDir + "\"+ $solutionName
$middletierSolutionPath=$CurrentDir + "\"+ $middleTierWSP 
$logfile=$CurrentDir + "\log.log"


Write-Host ''
Start-Transcript $logfile

Write-Host ''
Write-Host 'Powershell Script will now retract Middle Tier solution:' $middleTierWSP
#Removing ChatterMiddleTier.wsp#
$SolutionTocheck = Get-SPSolution -identity $middleTierWSP -ErrorAction:SilentlyContinue
if ($SolutionToCheck)
{
if ($SolutionToCheck.Deployed)
{
 write-host "Retracting Solution: " $middleTierWSP
 if ($SolutionToCheck.ContainsWebApplicationResource)
 {
  Uninstall-SPSolution -identity $SolutionToCheck -allwebapplications -Confirm:$false
 }
 else
 {
  Uninstall-SPSolution -identity $SolutionToCheck -Confirm:$false
 }
}
while ($SolutionToCheck.Deployed)
{
 start-sleep -s 15
 write-host "Waiting for Retraction to Complete"
}
start-sleep -s 15
write-host "Deleting Solution: " $middleTierWSP
Remove-SPSolution $SolutionToCheck -Confirm:$false
}


Write-Host ''
Write-Host 'Powershell Script will now retract Chatter Webpart solution:' $solutionName
#Removing SFChatterWebParts.wsp#
$SolutionTocheck = Get-SPSolution -identity $solutionName -ErrorAction:SilentlyContinue
if ($SolutionToCheck)
{
if ($SolutionToCheck.Deployed)
{
 write-host "Retracting Solution: " $solutionName
 if ($SolutionToCheck.ContainsWebApplicationResource)
 {
  Uninstall-SPSolution -identity $SolutionToCheck -allwebapplications -Confirm:$false
 }
 else
 {
  Uninstall-SPSolution -identity $SolutionToCheck -Confirm:$false
 }
}
while ($SolutionToCheck.Deployed)
{
 start-sleep -s 15
 write-host "Waiting for Retraction to Complete"
}
start-sleep -s 15
write-host "Deleting Solution: " $SolutionName
Remove-SPSolution $SolutionToCheck -Confirm:$false
}

Write-Host ''
Write-Host 'Powershell Script will now add solution:' $middleTierWSP
Add-SPSolution $middletierSolutionPath

Write-Host ''
Write-Host 'Powershell Script will now add solution:' $solutionName
Add-SPSolution $SolutionPath

Write-Host ''
Write-Host 'Salesforce chatter web part solution gets installed successfully'

Write-Host ''
Stop-Transcript

Remove-PsSnapin Microsoft.SharePoint.PowerShell